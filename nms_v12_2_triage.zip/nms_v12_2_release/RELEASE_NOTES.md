# NMS v12.2 — Triage & Hardening Pass

A focused pass over v12.1 Gold Master that found and fixed four real bugs,
added config plumbing that was missing, and established an integration
test harness for ongoing regression protection.

## Bugs fixed

**1. Source file encoding corruption (cosmetic → legibility).**
Both `v12-nms-server-PRODUCTION.py` (160 lines) and
`v12_1-nms-client-PRODUCTION.py` (123 lines) contained
double/triple-encoded UTF-8 via Windows cp1252 round-tripping. Every
log message containing an emoji or box-drawing character rendered as
garbled bytes in console output — e.g. `Ã°Å¸Å¡â‚¬` instead of `🚀`.
Fixed by `fix_mojibake.py` (included in tests/). The tool handles
cp1252 smart-punct that doesn't round-trip cleanly by falling back to
byte-level substitution for the known Windows-1252 special characters.
One hand-fixed line where the mojibake had bit-rotted beyond
algorithmic recovery (line 1262 tree-art restored as `└─`).

**2. `transfer_port` not config-driven (regression risk: port collision).**
The file-transfer channel port was hardcoded to `self.transfer_port =
CONFIG.get("transfer_port", 2223)`, but no `transfer_port` key existed
anywhere in the INI. If you overrode `[server] port` to avoid a
collision, transfer would still bind 2223 — and two NMS instances on
one host could never coexist. Added to `[server] transfer_port` in the
INI with a documented default.

**3. Re-registration clobber (race condition in production).**
When a client reconnects before the server has noticed the old socket
is dead, `self.clients[client_id] = new_client` silently replaced the
record without closing the old socket or tearing down the old message
loop. Two threads would then race on the same dict entry, with
messages landing on the wrong queue. Fixed with explicit eviction:
detect existing record, shut down old socket cleanly, log the event,
install new record.

**4. Identity-blind `finally` clobber (follow-up to #3).**
After fixing #3, the OLD thread's `finally` block would STILL fire
later and set `self.clients[client_id].connection = None` — but by
then the entry had been replaced by the NEW client. The clobber moved
from the handshake to the teardown, with identical symptoms. Fixed
with identity check: `finally` now verifies `self.clients[client_id]
is client` before clearing, so the old thread only cleans up its own
record. Also added null-guards for the case where handshake fails
before the `client` local is assigned.

**Bonus:** Python 3.12 deprecation warning around
`sqlite3`'s default datetime adapter silenced by explicit
`register_adapter` / `register_converter` calls. Warnings were
harmless but noisy in test output.

## New config key

`[server] transfer_port` — separate port for chunked MSI/package
deployments. Defaults to `2223`. Must be reachable by clients. If you
override `port`, override this too.

## Test harness: `tests/test_nms_integration.py`

12 integration tests, 13 seconds end-to-end, 0 skipped.

Design: real TCP sockets, real server + client launched as threads in
the pytest process. Each test gets its own tempdir, fresh DB, and
ephemeral ports — they can run in parallel and leave no state behind.

Coverage:

- **TestServerBoot** (3 tests): server binds on configured port;
  transfer_port honors INI; two envs coexist on same host without
  collision (regression against the hardcoded-2223 bug).
- **TestClientRegistration** (3 tests): client registers via JSON
  handshake; system info fields populated; reconnect cleanly evicts
  stale session (regression against re-registration clobber).
- **TestHeartbeat** (2 tests): server-side `last_seen` advances with
  client heartbeats; client stays online across multiple intervals.
- **TestDisconnect** (1 test): hard-closed client socket is detected
  within 3 seconds and server record flips to OFFLINE.
- **TestInventory** (1 test): `inventory_report` message writes
  correctly to `software_inventory` table; `clients.software_count`
  updates.
- **TestProtocolRobustness** (2 tests): garbage-JSON on handshake
  doesn't affect other clients or crash server; 5MB no-newline
  payload triggers `MAX_LINE_BYTES` defense without DoSing.

## Running the tests

From the release root:

    pip install pytest cryptography colorama
    python -m pytest tests/ -v

Tests run on Linux, macOS, and Windows. Expect identical pass results
across platforms.

## What wasn't touched (known scope for future passes)

- **File transfer channel**: Phase E/V8 chunked deployment flow is not
  yet in the test harness. Needs package-deploy round-trip test.
- **VPN bridge integration**: the NMS and VPN server are separate
  processes; VPN-side testing is tracked separately.
- **Inventory gathering on non-Windows**: client's `_run_wmic_inventory`
  is Windows-only by necessity. A synthetic inventory path (for tests
  or Linux agents) could be added later.
- **Credential push round-trip**: exercised in production but not yet
  pinned by a test.

## Files shipped

    server/
      nms_server.py                    ← fixed
      v12-nms-server-PRODUCTION.py     ← identical (gold master name)
      nms_server_config.ini            ← documents transfer_port
      dhcp_menu_v12.py                 ← unchanged
      file_transfer.py                 ← unchanged
      inventory_browser_methods.py     ← unchanged
      inventory_viewer.py              ← unchanged
      network_utils.py                 ← unchanged
      setup_server.py                  ← unchanged
      virtual_dhcp_v12.py              ← unchanged
      requirements.txt                 ← unchanged

    client/
      nms_client.py                    ← fixed (mojibake only)
      v12_1-nms-client-PRODUCTION.py   ← identical (gold master name)
      nms_client_config.ini            ← unchanged
      client_config.ini                ← unchanged
      file_transfer.py                 ← unchanged
      setup_client.py                  ← unchanged
      vpn_client_handler.py            ← unchanged

    tests/
      test_nms_integration.py          ← new (12 tests)
      fix_mojibake.py                  ← new (reusable tool)

## Sessions invested

One session of focused work: boot the suite, find bugs by reading and
running, fix each with a test that pins the regression, ship.
