"""
NMS integration test harness.

Spins up the NMS server and client in the same pytest process as
threads, exercises real wire-protocol round-trips, and asserts
outcomes. No subprocess orchestration — everything is thread-local
and cleanable.

Design:
  - One `NMSTestEnv` fixture per test. Creates a fresh temp dir,
    writes minimal config, launches server on an ephemeral port,
    yields a helper object, shuts everything down in teardown.
  - Client instances created on demand via `env.spawn_client()`.
  - All comms are real TCP sockets on 127.0.0.1. No mocking.
  - Ephemeral port selection avoids cross-test collisions.

These tests are quality gates for future changes — if a refactor
breaks the wire protocol, one of these red-lights.
"""

from __future__ import annotations

import importlib
import shutil
import socket
import sys
import tempfile
import threading
import time
from contextlib import closing
from pathlib import Path

import pytest


# Make the server and client modules importable
SERVER_DIR = Path(__file__).parent / "server"
CLIENT_DIR = Path(__file__).parent / "client"


def _free_port() -> int:
    """Pick an unused port."""
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_port(port: int, timeout: float = 3.0) -> bool:
    """Poll until a port accepts connections."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with closing(socket.create_connection(("127.0.0.1", port), timeout=0.2)):
                return True
        except OSError:
            time.sleep(0.05)
    return False


def _import_fresh(name: str, path: Path):
    """Import a module, fresh. Used to isolate per-test config."""
    # Remove cached
    for k in list(sys.modules.keys()):
        if k == name or k.startswith(f"{name}."):
            del sys.modules[k]
    sys.path.insert(0, str(path))
    try:
        return importlib.import_module(name)
    finally:
        sys.path.remove(str(path))


class NMSTestEnv:
    """Holds a running NMS server and spawns clients against it."""

    def __init__(self, tmpdir: Path):
        self.tmpdir = tmpdir
        self.server_dir = tmpdir / "server"
        self.client_dir = tmpdir / "client"
        # Copy server + client files into isolated working dirs
        shutil.copytree(SERVER_DIR, self.server_dir)
        shutil.copytree(CLIENT_DIR, self.client_dir)
        # Pick ports
        self.control_port = _free_port()
        self.transfer_port = _free_port()
        # Write server config with overrides
        self._write_server_config()
        # Lazy init
        self._server_module = None
        self._server = None
        self._client_threads: list[threading.Thread] = []
        self._clients: list = []

    def _write_server_config(self):
        cfg = self.server_dir / "nms_server_config.ini"
        cfg.write_text(f"""[server]
host = 127.0.0.1
port = {self.control_port}
transfer_port = {self.transfer_port}

[database]
path = {self.server_dir}/test.db
auto_backup = false
backup_dir = {self.server_dir}/backups

[credentials]
skip_credential_prompt = true

[deployables]
packages_dir = {self.server_dir}/deployables
max_package_size_mb = 500

[security]
require_tls = false

[logging]
log_level = WARNING
log_to_file = false
log_file = test.log

[performance]
max_clients = 100
client_timeout = 300
db_pool_size = 10

[dhcp]
enabled = false
bridge_interface = none
network = 192.168.99.0
subnet_mask = 255.255.255.0
gateway = 192.168.99.1
pool_start = 192.168.99.100
pool_end = 192.168.99.200
dns_servers = 192.168.99.10
""")

    def start_server(self):
        # chdir to the server dir so it finds its config
        original_cwd = Path.cwd()
        try:
            import os
            os.chdir(self.server_dir)
            self._server_module = _import_fresh("nms_server", self.server_dir)
            self._server = self._server_module.NetworkManagementServer(
                config_path=str(self.server_dir / "config"),
                db_path=str(self.server_dir / "test.db"),
            )
            self._server.start_server(host="127.0.0.1", port=self.control_port)
        finally:
            os.chdir(original_cwd)
        assert _wait_for_port(self.control_port, timeout=3.0), \
            f"server did not come up on port {self.control_port}"
        return self._server

    def spawn_client(self) -> "ClientHandle":
        """Start a client in its own thread and return a handle."""
        client_module = _import_fresh("nms_client", self.client_dir)
        agent = client_module.NetworkAgent(host="127.0.0.1", port=self.control_port)

        # Make the heartbeat short so timing tests finish fast
        client_module.CONFIG["heartbeat_interval"] = 1

        t = threading.Thread(target=agent.connect, daemon=True)
        t.start()
        self._client_threads.append(t)
        self._clients.append(agent)

        # Wait for the client to register on the server
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline:
            if agent.client_id in self._server.clients:
                return ClientHandle(agent, self._server)
            time.sleep(0.05)
        raise TimeoutError(f"client {agent.client_id} did not register within 3s")

    @property
    def server(self):
        return self._server

    def stop(self):
        # Stop clients first
        for a in self._clients:
            a.running = False
            try:
                if a.socket:
                    a.socket.close()
            except Exception:
                pass
        # Stop server
        if self._server is not None:
            try:
                self._server.running = False
                if self._server.server_socket:
                    self._server.server_socket.close()
                if self._server.transfer_socket:
                    self._server.transfer_socket.close()
            except Exception:
                pass


class ClientHandle:
    """A registered client + a shortcut to its server-side record."""
    def __init__(self, agent, server):
        self.agent = agent
        self.server = server
        self.client_id = agent.client_id

    @property
    def server_record(self):
        return self.server.clients.get(self.client_id)


@pytest.fixture
def env():
    with tempfile.TemporaryDirectory() as tmp:
        e = NMSTestEnv(Path(tmp))
        e.start_server()
        try:
            yield e
        finally:
            e.stop()


# ----- Actual tests -----


class TestServerBoot:
    def test_server_comes_up_on_configured_port(self, env):
        assert _wait_for_port(env.control_port, timeout=1.0)

    def test_transfer_port_honors_config(self, env):
        """Bug fix: transfer_port used to be hardcoded at 2223 regardless
        of config. We now set it per test env."""
        assert env.server.transfer_port == env.transfer_port
        assert _wait_for_port(env.transfer_port, timeout=1.0)

    def test_two_envs_do_not_collide(self):
        """Two environments must pick different ports and coexist.
        Regression against the old hardcoded-2223 bug."""
        with tempfile.TemporaryDirectory() as t1, tempfile.TemporaryDirectory() as t2:
            e1 = NMSTestEnv(Path(t1))
            e2 = NMSTestEnv(Path(t2))
            e1.start_server()
            try:
                e2.start_server()
            finally:
                e1.stop()
                try: e2.stop()
                except Exception: pass
            assert e1.transfer_port != e2.transfer_port
            assert e1.control_port != e2.control_port


class TestClientRegistration:
    def test_client_registers(self, env):
        c = env.spawn_client()
        assert c.server_record is not None
        assert c.server_record.is_online()

    def test_client_system_info_populated(self, env):
        c = env.spawn_client()
        rec = c.server_record
        assert rec.hostname != ""
        assert rec.os_type in ("linux", "windows", "darwin", "unknown")
        assert rec.ip_address != ""

    def test_reconnect_evicts_stale_session(self, env):
        """Client IDs are persistent per machine (uuid.getnode()). If the
        same client reconnects before the server notices the old socket
        is dead, the new handshake must cleanly evict the old session
        rather than leaving two threads racing on the same Client object.
        Regression: previously the server silently overwrote the record
        without closing the old socket or updating status."""
        c1 = env.spawn_client()
        first_conn = c1.server_record.connection
        assert first_conn is not None

        # Spawn another client with the same client_id (same machine
        # from the OS perspective, so uuid.getnode() returns the same)
        c2 = env.spawn_client()
        assert c1.client_id == c2.client_id, \
            "on same machine uuid.getnode() is stable — this is by design"
        # The server should have switched to the new connection
        time.sleep(0.3)
        new_conn = env.server.clients[c1.client_id].connection
        assert new_conn is not None
        assert new_conn is not first_conn, \
            "server did not install new connection on reconnect"

        # Old socket should be closed (fileno returns -1 after close)
        assert first_conn.fileno() == -1, \
            "server did not close old socket on reconnect"


class TestHeartbeat:
    def test_heartbeat_keeps_client_online(self, env):
        c = env.spawn_client()
        # Record initial heartbeat time
        initial = c.server_record.last_seen
        # Wait through at least one heartbeat interval (1s in test config)
        time.sleep(2.5)
        # The server's last_seen should have advanced
        assert c.server_record.last_seen > initial, \
            "heartbeat did not update server-side last_seen"

    def test_client_stays_online_through_heartbeats(self, env):
        c = env.spawn_client()
        # Client should remain online for at least 3s of heartbeats
        for _ in range(3):
            time.sleep(1)
            assert c.server_record.is_online(), "client fell offline unexpectedly"


class TestDisconnect:
    def test_disconnect_updates_server_record(self, env):
        """When a client socket drops, the server-side record must
        reflect the disconnect within a short window: connection should
        become None and status should flip to OFFLINE.
        Regression against the scenario where a client silently goes
        away (crash, power loss) and the server keeps thinking it's
        connected."""
        c = env.spawn_client()
        assert c.server_record.is_online()
        assert c.server_record.connection is not None

        # Hard shut the client. Set running=False first so the client's
        # auto-reconnect loop exits instead of racing back to re-register.
        c.agent.running = False
        try:
            c.agent.socket.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        c.agent.socket.close()

        # The server's reader thread should notice the FIN within ~1s.
        # Poll for up to 3s.
        from nms_server import ClientStatus
        deadline = time.monotonic() + 3.0
        cleared = False
        while time.monotonic() < deadline:
            rec = env.server.clients.get(c.client_id)
            # If the client auto-reconnected, the connection may have been
            # replaced — skip if that happened and warn
            if rec.status == ClientStatus.OFFLINE or rec.connection is None:
                cleared = True
                break
            time.sleep(0.1)
        assert cleared, (
            f"server still thinks client is connected 3s after hard close: "
            f"status={rec.status.value} connection={rec.connection}"
        )


class TestInventory:
    def test_inventory_report_updates_database(self, env):
        """A client sending an inventory_report should result in server-
        side DB rows for software_inventory. Exercises the message-loop
        dispatch and the SQLite write path end-to-end."""
        import json, sqlite3
        from pathlib import Path

        c = env.spawn_client()
        sock = c.agent.socket

        # Send a synthetic inventory_report directly on the established
        # control channel (bypasses the WMIC gathering which requires Windows)
        inventory_msg = {
            'type': 'inventory_report',
            'client_id': c.client_id,
            'inventory': {
                'hardware': {
                    'cpu': 'Intel Test CPU',
                    'ram': '16 GB',
                    'disk': '500 GB SSD',
                },
                'software': [
                    {'name': 'TestApp 1', 'version': '1.0',
                     'vendor': 'Acme', 'install_date': '2025-01-01'},
                    {'name': 'TestApp 2', 'version': '2.5',
                     'vendor': 'Globex', 'install_date': '2025-06-15'},
                ],
            },
        }
        line = (json.dumps(inventory_msg) + "\n").encode("utf-8")
        sock.sendall(line)

        # Give the server reader thread time to process + DB write
        time.sleep(1.0)

        # Verify DB was updated
        db_path = env.server_dir / "test.db"
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT software_name, software_version, vendor FROM software_inventory "
            "WHERE client_id = ? ORDER BY software_name",
            (c.client_id,),
        )
        rows = cur.fetchall()
        conn.close()
        assert len(rows) == 2, f"expected 2 software rows, got {len(rows)}"
        assert rows[0][0] == 'TestApp 1'
        assert rows[1][0] == 'TestApp 2'

        # And the client.software_count should reflect this
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT software_count FROM clients WHERE client_id = ?",
            (c.client_id,),
        )
        (count,) = cur.fetchone()
        conn.close()
        assert count == 2


class TestProtocolRobustness:
    def test_server_survives_garbage_input(self, env):
        """A malicious / buggy client sending non-JSON garbage on the
        handshake should be dropped cleanly without crashing the server
        or affecting other clients."""
        c_legit = env.spawn_client()
        assert c_legit.server_record is not None

        # Now send garbage on a new connection
        garbage_sock = socket.create_connection(("127.0.0.1", env.control_port))
        garbage_sock.sendall(b"this is not json\n")
        garbage_sock.close()
        time.sleep(0.3)

        # The legit client should still be connected and healthy
        assert c_legit.server_record.is_online()
        # Server should still accept new connections
        c2 = env.spawn_client()
        assert c2.server_record is not None

    def test_server_survives_oversized_line(self, env):
        """A client that spams a huge payload without newlines should
        hit MAX_LINE_BYTES and be dropped. Regression against memory
        exhaustion by adversarial clients."""
        garbage_sock = socket.create_connection(("127.0.0.1", env.control_port))
        garbage_sock.settimeout(2.0)
        # Send 5MB in chunks. The server will raise and close partway
        # through — we catch BrokenPipe / ConnectionReset when that
        # happens. Total payload > MAX_LINE_BYTES guarantees the trip.
        chunk = b"x" * 65536
        try:
            for _ in range(80):  # 80 * 64KB = 5MB
                garbage_sock.sendall(chunk)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass  # server closed on us — exactly what we want
        try:
            garbage_sock.close()
        except OSError:
            pass

        # Small settle. Server still alive? Legit client can still register?
        time.sleep(0.3)
        c = env.spawn_client()
        assert c.server_record is not None
