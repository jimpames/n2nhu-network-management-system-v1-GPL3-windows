"""
Fix double/triple UTF-8→cp1252→UTF-8 mojibake in the NMS source files.

Classic Windows round-trip corruption: UTF-8 bytes were interpreted as
cp1252 and re-encoded to UTF-8, doubling the layers. Files in this
codebase show triple encoding in places. We unwind until either the
re-encoding step fails (cp1252 can't round-trip) or no more high-byte
cp1252-esque sequences remain.

Usage: python3 fix_mojibake.py <file> [file ...]
       (writes <file>.fixed alongside original; user reviews diff)
"""

from __future__ import annotations
import sys
from pathlib import Path


def try_unwind_line(line: str, max_passes: int = 3) -> tuple[str, int]:
    """Unwind mojibake on a single line, up to max_passes.

    Uses cp1252 if possible (handles smart quotes/em-dash); falls back
    to a char-by-char method that substitutes cp1252 smart-punct to
    their single-byte equivalents, then does latin1. This tolerates
    occasional bytes that are undefined in cp1252.

    Returns (possibly-fixed line, number of passes applied).
    """
    passes = 0
    current = line
    for _ in range(max_passes):
        new = _one_unwind(current)
        if new is None or new == current:
            break
        current = new
        passes += 1
    return current, passes


def _one_unwind(s: str) -> str | None:
    """One mojibake-reversal pass. Returns new string or None if no change possible."""
    # First try clean cp1252 round-trip
    try:
        return s.encode("cp1252").decode("utf-8")
    except UnicodeEncodeError:
        pass
    except UnicodeDecodeError:
        return None

    # cp1252 failed — line has a char cp1252 doesn't define. Build the byte
    # sequence char-by-char, subbing smart-punct to cp1252 byte positions
    # and mapping all other non-latin1 chars to '?'.
    cp1252_map = {
        "\u2018": 0x91, "\u2019": 0x92, "\u201c": 0x93, "\u201d": 0x94,
        "\u2013": 0x96, "\u2014": 0x97, "\u2022": 0x95,
        "\u20ac": 0x80, "\u2026": 0x85, "\u2020": 0x86, "\u2021": 0x87,
        "\u02c6": 0x88, "\u2030": 0x89, "\u0160": 0x8a, "\u2039": 0x8b,
        "\u0152": 0x8c, "\u017d": 0x8e, "\u02dc": 0x98, "\u2122": 0x99,
        "\u0161": 0x9a, "\u203a": 0x9b, "\u0153": 0x9c, "\u017e": 0x9e,
        "\u0178": 0x9f,
    }
    out = bytearray()
    for ch in s:
        cp = ord(ch)
        if cp < 0x100:
            out.append(cp)
        elif ch in cp1252_map:
            out.append(cp1252_map[ch])
        else:
            # Give up on this char — don't corrupt, just abandon
            return None
    try:
        return out.decode("utf-8")
    except UnicodeDecodeError:
        return None


def fix_file(path: Path, max_passes: int = 3) -> dict:
    """Fix mojibake line-by-line. Tolerates lines that can't round-trip
    through cp1252 (leaves them alone). Writes .fixed sibling."""
    original = path.read_bytes()
    try:
        text = original.decode("utf-8")
    except UnicodeDecodeError as e:
        return {"path": str(path), "status": "skip", "reason": f"not utf-8: {e}"}

    lines_in = text.split("\n")
    lines_out = []
    total_passes = 0
    changed_lines = 0
    for line in lines_in:
        fixed, passes = try_unwind_line(line, max_passes)
        if passes > 0:
            changed_lines += 1
            total_passes += passes
        lines_out.append(fixed)

    if changed_lines == 0:
        return {"path": str(path), "status": "clean"}

    new_text = "\n".join(lines_out)
    out_path = path.with_suffix(path.suffix + ".fixed")
    out_path.write_text(new_text, encoding="utf-8")
    return {
        "path": str(path),
        "status": "fixed",
        "lines_changed": changed_lines,
        "total_unwind_passes": total_passes,
        "output": str(out_path),
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: fix_mojibake.py <file> [file ...]")
        sys.exit(2)
    for arg in sys.argv[1:]:
        result = fix_file(Path(arg))
        print(result)
