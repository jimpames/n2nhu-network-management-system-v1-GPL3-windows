#!/usr/bin/env python3
"""
N2NHU VPN Client - Automated Setup Script

Automates complete client installation:
1. Checks prerequisites
2. Installs Python dependencies
3. Downloads/installs TAP driver
4. Configures network adapters
5. Creates network bridge
6. Tests connectivity
"""

import subprocess
import sys
import os
import platform
import configparser

class ClientSetup:
    def __init__(self):
        self.config = configparser.ConfigParser()
        self.config.read('client_config.ini')
        
    def check_windows(self):
        """Verify running on Windows"""
        if platform.system() != 'Windows':
            print("="*70)
            print("ERROR: This client requires Windows")
            print("="*70)
            print("The TAP adapter and network bridging require Windows.")
            return False
        
        print("[CHECK] âœ“ Running on Windows")
        return True
    
    def check_admin(self):
        """Check for administrator privileges"""
        try:
            import ctypes
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
            if not is_admin:
                print("\n" + "="*70)
                print("ERROR: Administrator privileges required")
                print("="*70)
                print("Please run this script as Administrator:")
                print("1. Right-click on Command Prompt")
                print("2. Select 'Run as administrator'")
                print("3. Navigate to this directory and run again")
                return False
            
            print("[CHECK] âœ“ Running with Administrator privileges")
            return True
        except:
            print("[WARNING] Could not verify admin privileges")
            return True
    
    def check_python_version(self):
        """Verify Python version >= 3.7"""
        version = sys.version_info
        if version.major < 3 or (version.major == 3 and version.minor < 7):
            print(f"[ERROR] Python 3.7+ required (found {version.major}.{version.minor})")
            return False
        
        print(f"[CHECK] âœ“ Python {version.major}.{version.minor}.{version.micro}")
        return True
    
    def install_dependencies(self):
        """Install Python dependencies"""
        print("\n[STEP 1] Installing Python dependencies...")
        
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'],
                         check=True)
            print("[SUCCESS] âœ“ Dependencies installed")
            return True
        except Exception as e:
            print(f"[ERROR] Dependency installation failed: {e}")
            return False
    
    def check_tap_driver(self):
        """Check if TAP driver tools are available (modern or legacy)"""
        print("\n[STEP 2] Checking TAP driver tools...")
        
        # Check for modern tapctl.exe (OpenVPN 2.4+)
        modern_paths = [
            r"C:\Program Files\OpenVPN\bin\tapctl.exe",
            r"C:\Program Files (x86)\OpenVPN\bin\tapctl.exe",
            "tapctl.exe"
        ]
        
        for path in modern_paths:
            if os.path.exists(path):
                print(f"[SUCCESS] ✓ Modern TAP tool found: {path}")
                print("[INFO] Using tapctl.exe (OpenVPN 2.4+)")
                # Check if TAP adapter exists
                return self.check_tap_adapter_exists()
        
        # Check for legacy tapinstall.exe (OpenVPN 2.3 and earlier)
        legacy_paths = [
            r"C:\Program Files\TAP-Windows\bin\tapinstall.exe",
            r"C:\Program Files (x86)\TAP-Windows\bin\tapinstall.exe",
            "tapinstall.exe"
        ]
        
        for path in legacy_paths:
            if os.path.exists(path):
                print(f"[SUCCESS] ✓ Legacy TAP tool found: {path}")
                print("[INFO] Using tapinstall.exe (OpenVPN 2.3)")
                # Check if TAP adapter exists
                return self.check_tap_adapter_exists()
        
        print("[INFO] TAP driver tools not found")
        print("\n" + "="*70)
        print("TAP DRIVER INSTALLATION REQUIRED")
        print("="*70)
        print("Please install OpenVPN to get the TAP driver:")
        print("1. Download: https://openvpn.net/community-downloads/")
        print("2. Run installer")
        print("3. Ensure 'TAP Virtual Ethernet Adapter' is selected")
        print("4. Complete installation")
        print("5. Re-run this setup")
        print("="*70)
        
        return False
    
    def check_tap_adapter_exists(self):
        """Check if TAP adapter already exists using ipconfig"""
        try:
            result = subprocess.run(['ipconfig', '/all'], 
                                  capture_output=True, 
                                  text=True,
                                  encoding='cp1252')
            
            # Look for TAP adapter in output
            if 'TAP-Windows' in result.stdout or 'tap0901' in result.stdout.lower():
                print("[SUCCESS] ✓ TAP adapter already installed!")
                print("[INFO] Adapter will be configured during client setup")
                return True
            else:
                print("[INFO] TAP driver found but no adapter created yet")
                print("[INFO] Client setup will create the adapter")
                return True  # Return True because we have the tools
                
        except Exception as e:
            print(f"[WARNING] Could not check for TAP adapter: {e}")
            return True  # Assume it's OK
    
    def setup_tap_adapter(self):
        """Setup TAP adapter and bridge"""
        print("\n[STEP 3] Setting up TAP adapter and network bridge...")
        
        try:
            subprocess.run([sys.executable, 'vpn_client.py', '--setup'], check=True)
            print("[SUCCESS] âœ“ Network configuration complete")
            return True
        except Exception as e:
            print(f"[ERROR] Network setup failed: {e}")
            print("[INFO] You can run setup manually: python vpn_client.py --setup")
            return False
    
    def test_connectivity(self):
        """Test connectivity to VPN server"""
        print("\n[STEP 4] Testing server connectivity...")
        
        server_host = self.config.get('server', 'host', fallback='customer.notcloudai.com')
        server_port = self.config.getint('server', 'port', fallback=2222)
        
        print(f"[INFO] Testing connection to {server_host}:{server_port}...")
        
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((server_host, server_port))
            sock.close()
            
            if result == 0:
                print(f"[SUCCESS] âœ“ Server is reachable!")
                return True
            else:
                print(f"[WARNING] Cannot reach server (error code: {result})")
                print(f"[INFO] This is OK if the server isn't running yet")
                return True
        except Exception as e:
            print(f"[WARNING] Connectivity test failed: {e}")
            print(f"[INFO] Make sure VPN server is running")
            return True
    
    def create_start_scripts(self):
        """Create convenient start scripts"""
        print("\n[STEP 5] Creating start scripts...")
        
        # Start VPN client script
        client_script = """@echo off
echo Starting N2NHU VPN Client...
echo.
python vpn_client.py
pause
"""
        
        with open('start_vpn.bat', 'w') as f:
            f.write(client_script)
        
        # Silent startup script (for auto-start)
        silent_script = """@echo off
start /min python vpn_client.py
"""
        
        with open('start_vpn_silent.bat', 'w') as f:
            f.write(silent_script)
        
        print("[SUCCESS] âœ“ Start scripts created:")
        print("  - start_vpn.bat        (Start VPN client)")
        print("  - start_vpn_silent.bat (Start minimized)")
        
        return True
    
    def configure_autostart(self):
        """Optionally configure auto-start on Windows boot"""
        print("\n[STEP 6] Auto-start configuration...")
        
        auto_start = self.config.getboolean('client', 'auto_start', fallback=False)
        
        if not auto_start:
            print("[INFO] Auto-start is disabled in config")
            choice = input("Enable auto-start on Windows boot? [y/N]: ").strip().lower()
            
            if choice != 'y':
                print("[INFO] Skipping auto-start configuration")
                return True
        
        # Add to Windows startup
        try:
            startup_folder = os.path.join(
                os.environ['APPDATA'],
                'Microsoft\\Windows\\Start Menu\\Programs\\Startup'
            )
            
            startup_script = os.path.join(startup_folder, 'N2NHU-VPN.bat')
            current_dir = os.getcwd()
            
            with open(startup_script, 'w') as f:
                f.write(f'@echo off\ncd /d "{current_dir}"\nstart /min python vpn_client.py\n')
            
            print(f"[SUCCESS] âœ“ Auto-start configured")
            print(f"[INFO] VPN will start automatically on Windows boot")
            return True
            
        except Exception as e:
            print(f"[WARNING] Could not configure auto-start: {e}")
            return True
    
    def print_summary(self):
        """Print setup summary"""
        print("\n" + "="*70)
        print("CLIENT SETUP COMPLETE!")
        print("="*70)
        print()
        print("Next steps:")
        print()
        print("1. Ensure VPN server is running")
        print()
        print("2. Start the VPN client:")
        print("   Option A: Run start_vpn.bat")
        print("   Option B: python vpn_client.py")
        print()
        print("3. Client will:")
        print("   - Connect to VPN server")
        print("   - Receive corporate IP address")
        print("   - Auto-configure network")
        print("   - Establish Layer 2 VPN tunnel")
        print()
        print("4. Access corporate resources:")
        print("   - File shares: \\\\FILESERVER\\Share")
        print("   - Printers: By name (auto-discovered)")
        print("   - Internal apps: By hostname")
        print()
        print("="*70)
        print()
        print("Your client is now connected to the corporate network!")
        print("Remote work is now IDENTICAL to office work.")
        print()
    
    def run_setup(self):
        """Run complete setup process"""
        print("\n" + "="*70)
        print("N2NHU VPN CLIENT - AUTOMATED SETUP")
        print("="*70)
        print()
        
        # Prerequisites
        if not self.check_windows():
            return False
        
        if not self.check_admin():
            return False
        
        if not self.check_python_version():
            return False
        
        # Installation steps
        if not self.install_dependencies():
            return False
        
        if not self.check_tap_driver():
            return False
        
        # Network setup
        print("\n[INFO] Network setup is interactive")
        print("[INFO] Follow the prompts...")
        input("\nPress Enter to continue...")
        
        self.setup_tap_adapter()
        
        # Connectivity test
        self.test_connectivity()
        
        # Create scripts
        self.create_start_scripts()
        
        # Auto-start
        self.configure_autostart()
        
        # Summary
        self.print_summary()
        
        return True


def main():
    setup = ClientSetup()
    success = setup.run_setup()
    
    if success:
        print("\n[SUCCESS] Client setup completed successfully!")
        sys.exit(0)
    else:
        print("\n[ERROR] Setup encountered errors - please review messages above")
        sys.exit(1)


if __name__ == "__main__":
    main()
