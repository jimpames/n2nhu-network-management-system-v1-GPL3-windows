"""VPN Client Handler for N2NHU NMS Client - V10"""

import subprocess
import platform
import logging

logger = logging.getLogger(__name__)

class VPNClientHandler:
    """Handles VPN connection and IP configuration"""
    
    def __init__(self, nms_client):
        self.nms_client = nms_client
        self.vpn_connected = False
        self.vpn_config = None
    
    def request_vpn_connection(self):
        """Request VPN connection from server"""
        try:
            # Send VPN connection request to server
            request = {
                'type': 'vpn_connect_request',
                'client_id': self.nms_client.client_id,
                'hostname': self.nms_client.system_info.get('hostname'),
                'mac_address': self.nms_client.system_info.get('mac_address'),
                'wan_ip': self.nms_client.system_info.get('ip_address')
            }
            
            logger.info("📡 Requesting VPN connection from server...")
            # This would be sent via the NMS control channel
            # For now, it's a placeholder for the integration point
            
            return True
            
        except Exception as e:
            logger.error(f"VPN connection request failed: {e}")
            return False
    
    def handle_vpn_config(self, config):
        """Handle VPN configuration received from server"""
        try:
            self.vpn_config = config
            
            vpn_ip = config.get('vpn_ip')
            subnet_mask = config.get('subnet_mask', '255.255.255.0')
            gateway = config.get('gateway')
            dns_servers = config.get('dns_servers', [])
            
            logger.info(f"📥 Received VPN configuration:")
            logger.info(f"   VPN IP: {vpn_ip}")
            logger.info(f"   Subnet: {subnet_mask}")
            logger.info(f"   Gateway: {gateway}")
            if dns_servers:
                logger.info(f"   DNS: {', '.join(dns_servers)}")
            
            # Apply configuration to TAP adapter
            if self.apply_ip_to_adapter(vpn_ip, subnet_mask, gateway):
                self.vpn_connected = True
                logger.info("✅ VPN connected successfully!")
                return True
            else:
                logger.error("❌ Failed to apply IP configuration")
                return False
                
        except Exception as e:
            logger.error(f"Error handling VPN config: {e}")
            return False
    
    def apply_ip_to_adapter(self, ip_address, subnet_mask, gateway, adapter_name="N2NHU-Corporate"):
        """Apply IP address to virtual TAP adapter"""
        try:
            system = platform.system()
            
            if system == 'Windows':
                return self._apply_ip_windows(ip_address, subnet_mask, gateway, adapter_name)
            elif system == 'Linux':
                return self._apply_ip_linux(ip_address, subnet_mask, gateway, adapter_name)
            else:
                logger.error(f"Unsupported OS: {system}")
                return False
                
        except Exception as e:
            logger.error(f"Error applying IP: {e}")
            return False
    
    def _apply_ip_windows(self, ip_address, subnet_mask, gateway, adapter_name):
        """Apply IP on Windows using netsh"""
        try:
            logger.info(f"🔧 Configuring adapter '{adapter_name}' on Windows...")
            
            # Set static IP address
            cmd = [
                'netsh', 'interface', 'ip', 'set', 'address',
                f'name={adapter_name}',
                'static',
                ip_address,
                subnet_mask,
                gateway
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info(f"✅ IP configured: {ip_address}")
                return True
            else:
                logger.error(f"netsh failed: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Windows IP config failed: {e}")
            return False
    
    def _apply_ip_linux(self, ip_address, subnet_mask, gateway, adapter_name):
        """Apply IP on Linux using ip command"""
        try:
            logger.info(f"🔧 Configuring adapter '{adapter_name}' on Linux...")
            
            # Convert subnet mask to CIDR
            cidr = self._subnet_to_cidr(subnet_mask)
            
            # Set IP address
            cmd = ['sudo', 'ip', 'addr', 'add', f'{ip_address}/{cidr}', 'dev', adapter_name]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"ip addr failed: {result.stderr}")
                return False
            
            # Bring interface up
            cmd = ['sudo', 'ip', 'link', 'set', adapter_name, 'up']
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"ip link up failed: {result.stderr}")
                return False
            
            # Add default route
            if gateway:
                cmd = ['sudo', 'ip', 'route', 'add', 'default', 'via', gateway, 'dev', adapter_name]
                subprocess.run(cmd, capture_output=True, text=True)
                # Route might fail if already exists, that's ok
            
            logger.info(f"✅ IP configured: {ip_address}")
            return True
            
        except Exception as e:
            logger.error(f"Linux IP config failed: {e}")
            return False
    
    def _subnet_to_cidr(self, subnet_mask):
        """Convert subnet mask to CIDR notation"""
        # Simple conversion for common masks
        masks = {
            '255.255.255.0': '24',
            '255.255.0.0': '16',
            '255.0.0.0': '8',
            '255.255.255.128': '25',
            '255.255.255.192': '26',
            '255.255.255.224': '27',
            '255.255.255.240': '28',
            '255.255.255.248': '29',
            '255.255.255.252': '30'
        }
        return masks.get(subnet_mask, '24')
    
    def disconnect_vpn(self):
        """Disconnect VPN"""
        try:
            if not self.vpn_connected:
                logger.info("VPN not connected")
                return True
            
            logger.info("Disconnecting VPN...")
            # Placeholder for VPN disconnect logic
            self.vpn_connected = False
            self.vpn_config = None
            logger.info("✅ VPN disconnected")
            return True
            
        except Exception as e:
            logger.error(f"VPN disconnect failed: {e}")
            return False
    
    def get_vpn_status(self):
        """Get current VPN status"""
        return {
            'connected': self.vpn_connected,
            'config': self.vpn_config
        }
