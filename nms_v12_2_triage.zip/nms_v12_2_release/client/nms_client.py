#!/usr/bin/env python3
"""
N2NHU NETWORK MANAGEMENT AGENT - V4 ENHANCED
The "Player" for your Network Management Game

V3 ENHANCED FEATURES:
- Complete Hardware Inventory (CPU, RAM, Disk)
- MSI Package Deployment (Stage & Execute)
- Windows User Account Management (Create/Delete)
- Software Uninstallation
- Integrated VPN Client (On-Demand)
- Credential Vault for Remote Operations


V4 ENHANCEMENTS (February 2026):
- Chunked File Transfer (SHA256 verified)
- Progress Tracking  
- Memory Efficient (64KB constant)
- Enhanced Error Handling
"""

import socket
from vpn_client_handler import VPNClientHandler
import json
import time
import threading
import platform
import uuid
import subprocess
import os
import sys
import logging
import base64
import configparser
from datetime import datetime
from cryptography.fernet import Fernet

# V4 ENHANCED: File transfer module
from file_transfer import ChunkedFileReceiver, format_bytes



# ============================================================================
# NEWLINE-DELIMITED JSON FRAMING HELPERS (TCP-Safe)
# ============================================================================

MAX_LINE_BYTES = 4 * 1024 * 1024  # 4MB safety cap

def send_json_line(sock, obj):
    """Send JSON object with newline delimiter (TCP-safe)"""
    data = (json.dumps(obj, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")
    sock.sendall(data)

def recv_json_lines(sock, buffer):
    """Yield complete JSON objects from newline-delimited stream"""
    chunk = sock.recv(65536)
    if not chunk:
        raise ConnectionError("Socket closed by peer")
    buffer.extend(chunk)
    
    while True:
        nl = buffer.find(b"\n")
        if nl < 0:
            if len(buffer) > MAX_LINE_BYTES:
                raise ValueError("JSON line exceeds MAX_LINE_BYTES")
            return
        
        line = bytes(buffer[:nl])
        del buffer[:nl + 1]
        
        if not line.strip():
            continue
        
        if len(line) > MAX_LINE_BYTES:
            raise ValueError("Single JSON message too large")
        
        try:
            yield json.loads(line.decode("utf-8"))
        except json.JSONDecodeError as e:
            raise ValueError(f"Bad JSON line: {e}") from e




# ============================================================================
# V8: LENGTH-PREFIXED JSON HELPER (Transfer Channel)
# ============================================================================

def send_lp_json(sock, obj):
    """Send length-prefixed JSON (for transfer channel handshake)"""
    import struct
    data = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    sock.sendall(struct.pack("!I", len(data)) + data)


def load_config():
    """Load configuration from INI file or use defaults"""
    config = {
        'server_host': 'localhost',
        'server_port': 2222,
        'agent_version': '3.0.0-ENHANCED',
        'reconnect_interval': 5,
        'heartbeat_interval': 30,
        'vpn_client_script': 'vpn_client.py',
        'auto_start_vpn': False,
        'log_level': 'INFO',
        'log_to_file': False,
        'log_file': 'nms_client.log',
        'staging_dir': '',
        'cleanup_after_install': False
    }
    
    config_file = 'nms_client_config.ini'
    
    if os.path.exists(config_file):
        try:
            parser = configparser.ConfigParser()
            parser.read(config_file)
            
            # Server settings
            if parser.has_section('server'):
                config['server_host'] = parser.get('server', 'host', fallback=config['server_host'])
                config['server_port'] = parser.getint('server', 'port', fallback=config['server_port'])
            
            # Client settings
            if parser.has_section('client'):
                config['agent_version'] = parser.get('client', 'agent_version', fallback=config['agent_version'])
                config['reconnect_interval'] = parser.getint('client', 'reconnect_interval', fallback=config['reconnect_interval'])
                config['heartbeat_interval'] = parser.getint('client', 'heartbeat_interval', fallback=config['heartbeat_interval'])
            
            # VPN settings
            if parser.has_section('vpn'):
                config['vpn_client_script'] = parser.get('vpn', 'vpn_client_script', fallback=config['vpn_client_script'])
                config['auto_start_vpn'] = parser.getboolean('vpn', 'auto_start_vpn', fallback=config['auto_start_vpn'])
            
            # Logging settings
            if parser.has_section('logging'):
                config['log_level'] = parser.get('logging', 'log_level', fallback=config['log_level'])
                config['log_to_file'] = parser.getboolean('logging', 'log_to_file', fallback=config['log_to_file'])
                config['log_file'] = parser.get('logging', 'log_file', fallback=config['log_file'])
            
            # Staging settings
            if parser.has_section('staging'):
                config['staging_dir'] = parser.get('staging', 'staging_dir', fallback=config['staging_dir'])
                config['cleanup_after_install'] = parser.getboolean('staging', 'cleanup_after_install', fallback=config['cleanup_after_install'])
            
            print(f"✅ Loaded configuration from {config_file}")
            
        except Exception as e:
            print(f"⚠️  Error reading {config_file}: {e}")
            print("Using default configuration")
    else:
        print(f"â„¹ï¸  No {config_file} found, using defaults")
    
    return config


# Load configuration
CONFIG = load_config()

# Configuration (backward compatible)
SERVER_HOST = CONFIG['server_host']
SERVER_PORT = CONFIG['server_port']
AGENT_VERSION = CONFIG['agent_version']

# Configure Logging
log_level = getattr(logging, CONFIG['log_level'].upper(), logging.INFO)
log_handlers = []

if CONFIG['log_to_file']:
    log_handlers.append(logging.FileHandler(CONFIG['log_file']))

log_handlers.append(logging.StreamHandler())

logging.basicConfig(
    level=log_level,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=log_handlers
)
logger = logging.getLogger(__name__)



import ctypes

def check_is_running_as_admin():
    """Check if running with administrator privileges"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

class CredentialVault:
    """
    Local encrypted storage for credentials received from server
    """
    
    def __init__(self):
        self.credentials = None
        self.cipher = None
    
    def store_credentials(self, encrypted_creds: str, encryption_key: str):
        """Store encrypted credentials received from server"""
        try:
            # Decode encryption key
            key = base64.b64decode(encryption_key.encode())
            self.cipher = Fernet(key)
            
            # Decrypt credentials
            encrypted_bytes = base64.b64decode(encrypted_creds.encode())
            decrypted = self.cipher.decrypt(encrypted_bytes)
            self.credentials = json.loads(decrypted.decode())
            
            logger.info(f"🔑 Credentials stored: {self.credentials['type']}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to store credentials: {e}")
            return False
    
    def get_credentials(self):
        """Retrieve stored credentials"""
        return self.credentials
    
    def has_credentials(self):
        """Check if credentials are configured"""
        return self.credentials is not None
    
    def get_auth_flags(self):
        """Get WMIC authentication flags"""
        if not self.credentials:
            return ""
        
        if self.credentials['type'] == 'domain':
            domain = self.credentials['domain']
            username = self.credentials['username']
            password = self.credentials['password']
            return f'/node:localhost /user:{domain}\\{username} /password:{password}'
        else:
            username = self.credentials['username']
            password = self.credentials['password']
            return f'/node:localhost /user:{username} /password:{password}'


class VPNManager:
    """
    Manages VPN connection using vpn_client.py
    """
    
    def __init__(self):
        self.vpn_process = None
        self.vpn_running = False
    
    def start_vpn(self):
        """Start VPN connection"""
        if self.vpn_running:
            logger.warning("⚠️  VPN is already running")
            return False
        
        try:
            logger.info("🔌 Starting VPN connection...")
            
            # Check if vpn_client.py exists (use config)
            vpn_script = CONFIG.get('vpn_client_script', 'vpn_client.py')
            vpn_client_path = os.path.join(os.path.dirname(__file__), vpn_script)
            
            if not os.path.exists(vpn_client_path):
                logger.error("❌ vpn_client.py not found in current directory")
                return False
            
            # Start VPN client in subprocess
            self.vpn_process = subprocess.Popen(
                [sys.executable, vpn_client_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NEW_CONSOLE if platform.system() == 'Windows' else 0
            )
            
            self.vpn_running = True
            logger.info("✅ VPN client started in new window")
            logger.info("   Check the VPN client window for connection status")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to start VPN: {e}")
            return False
    
    def stop_vpn(self):
        """Stop VPN connection"""
        if not self.vpn_running or not self.vpn_process:
            logger.warning("⚠️  VPN is not running")
            return False
        
        try:
            logger.info("🛑 Stopping VPN connection...")
            
            self.vpn_process.terminate()
            self.vpn_process.wait(timeout=5)
            
            self.vpn_running = False
            self.vpn_process = None
            
            logger.info("✅ VPN stopped")
            return True
            
        except subprocess.TimeoutExpired:
            logger.warning("⚠️  VPN did not stop gracefully, forcing...")
            self.vpn_process.kill()
            self.vpn_running = False
            self.vpn_process = None
            return True
        except Exception as e:
            logger.error(f"❌ Failed to stop VPN: {e}")
            return False
    
    def status(self):
        """Get VPN status"""
        return "Running" if self.vpn_running else "Stopped"


class NetworkAgent:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.socket = None
        self.running = False
        self.client_id = self._generate_client_id()
        self.system_info = self._get_system_info()
        self.credential_vault = CredentialVault()
        self.transfer_in_progress = False  # V6: Pause heartbeat during transfer
        self.vpn_manager = VPNManager()
        # V12.1: Initialize VPN client handler for IP configuration
        self.vpn_handler = VPNClientHandler(self)

    def _generate_client_id(self):
        """Generate a persistent ID for this machine"""
        node = uuid.getnode()
        return f"agent_{node}"

    def _get_system_info(self):
        """Auto-discover local system details"""
        # Try to detect domain membership
        domain = None
        try:
            if platform.system().lower() == 'windows':
                result = subprocess.run(
                    'wmic computersystem get domain',
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    if len(lines) > 1:
                        domain_name = lines[1].strip()
                        if domain_name and domain_name.upper() != 'WORKGROUP':
                            domain = domain_name
        except:
            pass
        
        return {
            'client_id': self.client_id,
            'hostname': socket.gethostname(),
            'ip_address': socket.gethostbyname(socket.gethostname()),
            'mac_address': ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
                                   for ele in range(0, 8*6, 8)][::-1]),
            'os_type': platform.system().lower(),
            'os_version': platform.release(),
            'agent_version': AGENT_VERSION,
            'architecture': platform.machine(),
            'domain': domain
        }

    def connect(self):
        """Establish connection to N2NHU Server"""
        while True:
            try:
                logger.info(f"🔌 Connecting to Server {self.host}:{self.port}...")
                self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.socket.connect((self.host, self.port))
                self.running = True
                
                # 1. Send Handshake (Registration)
                logger.info("👋 Sending handshake...")
                send_json_line(self.socket, self.system_info)
                
                # 2. Wait for Ack (using framed receive)
                buffer = bytearray()
                for ack in recv_json_lines(self.socket, buffer):
                    break  # Get first message
                logger.info(f"✅ Connected! Server Time: {ack.get('server_time')}")
                
                # 3. Start Heartbeat Thread
                threading.Thread(target=self._heartbeat_loop, daemon=True).start()
                
                # 4. Main Command Loop
                self._command_loop()
                
            except ConnectionRefusedError:
                logger.error("❌ Connection refused. Retrying in 5s...")
                time.sleep(CONFIG.get('reconnect_interval', 5))
            except Exception as e:
                logger.error(f"⚠️ Error: {e}")
                time.sleep(CONFIG.get('reconnect_interval', 5))
            finally:
                if self.socket:
                    self.socket.close()

    def _command_loop(self):
        """Listen for server commands"""
        buffer = bytearray()  # Persistent buffer for TCP-safe framing
        while self.running:
            try:
                # TCP-safe framed receive (handles fragmentation)
                for command in recv_json_lines(self.socket, buffer):
                    logger.info(f"📥 Received Command: {command.get('type')}")
                    
                    # Process the command
                    result = self._execute_command(command)
                    
                    # Send result back if needed
                    if result and command.get('type') != 'credential_deploy':
                        response = {
                            'type': 'operation_result',
                            'result': result
                        }
                        send_json_line(self.socket, response)
                
            except (ConnectionError, OSError):
                logger.error("❌ Connection lost")
                break
            except Exception as e:
                logger.error(f"❌ Command loop error: {e}")
                break

    def handle_vpn_config(self, message):
        """V12.1: Handle VPN configuration from server"""
        try:
            logger.info("Received VPN configuration from server")
            
            vpn_config = message.get('config', {})
            status = message.get('status', 'ok')
            
            if status != 'ok':
                error = message.get('error', 'Unknown error')
                logger.error(f"VPN config failed: {error}")
                return
            
            if self.vpn_handler.handle_vpn_config(vpn_config):
                # Send success confirmation
                send_json_line(self.socket, {
                    'type': 'vpn_connect_result',
                    'client_id': self.client_id,
                    'status': 'connected',
                    'vpn_ip': vpn_config.get('vpn_ip')
                })
                logger.info(f"VPN connected with IP: {vpn_config.get('vpn_ip')}")
            else:
                # Send failure
                send_json_line(self.socket, {
                    'type': 'vpn_connect_result',
                    'client_id': self.client_id,
                    'status': 'failed',
                    'error': 'Failed to apply IP configuration'
                })
                logger.error("VPN connection failed")
        except Exception as e:
            logger.error(f"Error handling VPN config: {e}")
            send_json_line(self.socket, {
                'type': 'vpn_connect_result',
                'client_id': self.client_id,
                'status': 'failed',
                'error': str(e)
            })

    def _execute_command(self, command):
        """Execute the logic sent by the server"""
        cmd_type = command.get('type')
        start_time = time.time()
        
        result = {
            'operation_type': cmd_type,
            'status': 'failed',
            'exit_code': -1,
            'error_message': '',
            'duration_seconds': 0
        }

        try:
            if cmd_type == 'credential_deploy':
                # SERVER PUSHED CREDENTIALS
                logger.info("🔑 Receiving credentials from server...")
                
                encrypted_creds = command.get('credentials_encrypted')
                encryption_key = command.get('encryption_key')
                
                if self.credential_vault.store_credentials(encrypted_creds, encryption_key):
                    logger.info("✅ Credentials stored successfully!")
                    logger.info(f"   Type: {self.credential_vault.credentials['type']}")
                    
                    # Auto-trigger FULL inventory scan
                    logger.info("🚀 Auto-triggering FULL system inventory scan...")
                    time.sleep(1)
                    self._run_wmic_inventory()
                
                return None
            
            elif cmd_type == 'enhanced_package_deploy':
                # V4 ENHANCED: Chunked file transfer deployment
                logger.info("📦 V4 Enhanced deployment requested...")
                self.handle_enhanced_package_deploy(command)
                return None  # Handled separately, no standard result
            
            elif cmd_type == 'inventory_scan':
                # INVENTORY REFRESH
                logger.info("🔄 Full inventory scan requested by server...")
                
                if command.get('scan_software', True):
                    self._run_wmic_inventory()
                
                result['status'] = 'success'
                result['exit_code'] = 0
            
            elif cmd_type == 'stage_and_deploy':
                # MSI PACKAGE DEPLOYMENT (ENHANCED!)
                self._handle_package_deployment(command, result)
            
            elif cmd_type == 'software_uninstall':
                # SOFTWARE REMOVAL (ENHANCED!)
                self._handle_software_uninstall(command, result)
            
            elif cmd_type == 'user_account_create':
                # WINDOWS USER CREATION (ENHANCED!)
                self._handle_user_creation(command, result)
            
            elif cmd_type == 'user_account_delete':
                # WINDOWS USER DELETION (ENHANCED!)
                self._handle_user_deletion(command, result)
            
            elif cmd_type == 'remote_command':
                # REMOTE SHELL COMMAND
                cmd_str = command.get('command')
                if cmd_str:
                    logger.info(f"💻 Executing Shell: {cmd_str}")
                    proc = subprocess.run(
                        cmd_str, shell=True, capture_output=True, text=True
                    )
                    result['exit_code'] = proc.returncode
                    result['status'] = 'success' if proc.returncode == 0 else 'failed'
                    result['error_message'] = proc.stderr
                    logger.info(f"📄 Output: {proc.stdout[:50]}...")

            
            elif cmd_type == 'vpn_config':
                # V12.1: VPN CONFIGURATION FROM SERVER
                logger.info("VPN configuration received")
                self.handle_vpn_config(command)
                return None  # Handled separately, sends own response
            else:
                result['error_message'] = f"Unknown command type: {cmd_type}"

        except Exception as e:
            result['error_message'] = str(e)
            logger.error(f"❌ Execution Error: {e}")
        
        finally:
            result['duration_seconds'] = time.time() - start_time
        
        return result
    
    #
    # ================ ENHANCED COMMAND HANDLERS ================
    #
    
    def _handle_package_deployment(self, command, result):
        """Handle MSI package deployment"""
        filename = command.get('filename')
        b64_data = command.get('file_data')
        args = command.get('arguments', '')
        
        logger.info("=" * 70)
        logger.info(f"📦 STAGER: Receiving package {filename}...")
        logger.info("=" * 70)
        
        # Create Staging Directory (use config or temp)
        staging_base = CONFIG.get('staging_dir', '')
        if staging_base and os.path.exists(staging_base):
            staging_dir = staging_base
        else:
            staging_dir = os.path.join(os.getenv('TEMP'), 'N2NHU_Staging')
        
        if not os.path.exists(staging_dir):
            os.makedirs(staging_dir)
            logger.info(f"📁 Created staging directory: {staging_dir}")
        
        file_path = os.path.join(staging_dir, filename)
        
        try:
            # Decode and Write File
            logger.info("🔓 Decoding package data...")
            file_bytes = base64.b64decode(b64_data)
            file_size_mb = len(file_bytes) / 1024 / 1024
            logger.info(f"📊 Package size: {round(file_size_mb, 2)} MB")
            
            logger.info(f"💾 Writing to: {file_path}")
            with open(file_path, 'wb') as f:
                f.write(file_bytes)
            
            logger.info(f"✅ STAGER: File staged successfully!")
            logger.info(f"   Location: {file_path}")
            
            # EXECUTOR: "Automagically" Deploy
            logger.info("")
            logger.info("=" * 70)
            logger.info("🚀 EXECUTOR: Starting automated deployment...")
            logger.info("=" * 70)
            
            # Determine install command
            if filename.endswith('.msi'):
                install_cmd = f'msiexec /i "{file_path}" {args}'
                logger.info(f"📋 MSI Installation Command:")
            elif filename.endswith('.exe'):
                install_cmd = f'"{file_path}" {args}'
                logger.info(f"📋 EXE Execution Command:")
            else:
                install_cmd = f'"{file_path}"'
                logger.info(f"📋 Generic Execution Command:")
            
            logger.info(f"   {install_cmd}")
            logger.info("")
            logger.info("⏳ Running installer (this may take a moment)...")
            
            # Execute installation
            proc = subprocess.run(
                install_cmd, 
                shell=True, 
                capture_output=True, 
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            logger.info("")
            
            # Check result
            if proc.returncode == 0:
                logger.info("=" * 70)
                logger.info("✨ DEPLOYMENT SUCCESSFUL!")
                logger.info("=" * 70)
                result['status'] = 'success'
                result['exit_code'] = 0
                result['message'] = f'{filename} installed successfully'
            else:
                logger.error("=" * 70)
                logger.error(f"❌ DEPLOYMENT FAILED (Exit Code: {proc.returncode})")
                logger.error("=" * 70)
                if proc.stderr:
                    logger.error(f"Error Output: {proc.stderr[:500]}")
                result['status'] = 'failed'
                result['exit_code'] = proc.returncode
                result['error_message'] = proc.stderr[:500] if proc.stderr else 'Unknown error'
            
        except subprocess.TimeoutExpired:
            logger.error("❌ Installation timeout (exceeded 5 minutes)")
            result['error_message'] = 'Installation timeout'
            result['exit_code'] = -1
        except Exception as e:
            logger.error(f"❌ Staging/Deploy Error: {e}")
            result['error_message'] = str(e)
            result['exit_code'] = -1
            import traceback
            traceback.print_exc()
        finally:
            # Optional cleanup (based on config)
            if CONFIG.get('cleanup_after_install', False) and 'file_path' in locals() and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                    logger.info(f"🗑️  Cleaned up staged file: {file_path}")
                except Exception as e:
                    logger.warning(f"⚠️  Could not cleanup staged file: {e}")
    
    def _handle_software_uninstall(self, command, result):
        """Handle software uninstallation"""
        software_name = command.get('software_name')
        software_version = command.get('software_version')
        
        logger.info("=" * 70)
        logger.info(f"🗑️  UNINSTALLING: {software_name}")
        logger.info("=" * 70)
        
        try:
            # Use WMIC to uninstall
            # Note: This requires admin privileges
            uninstall_cmd = f'wmic product where "name=\'{software_name}\'" call uninstall /nointeractive'
            
            logger.info(f"📋 Uninstall Command: {uninstall_cmd}")
            logger.info("⏳ Executing uninstall (this may take a moment)...")
            
            proc = subprocess.run(
                uninstall_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if proc.returncode == 0 or "success" in proc.stdout.lower():
                logger.info("=" * 70)
                logger.info("✨ UNINSTALL SUCCESSFUL!")
                logger.info("=" * 70)
                result['status'] = 'success'
                result['exit_code'] = 0
            else:
                logger.error("=" * 70)
                logger.error(f"❌ UNINSTALL FAILED (Exit Code: {proc.returncode})")
                logger.error("=" * 70)
                if proc.stderr:
                    logger.error(f"Error: {proc.stderr[:500]}")
                result['status'] = 'failed'
                result['exit_code'] = proc.returncode
                result['error_message'] = proc.stderr[:500] if proc.stderr else 'Uninstall failed'
        
        except subprocess.TimeoutExpired:
            logger.error("❌ Uninstall timeout")
            result['error_message'] = 'Uninstall timeout'
            result['exit_code'] = -1
        except Exception as e:
            logger.error(f"❌ Uninstall Error: {e}")
            result['error_message'] = str(e)
            result['exit_code'] = -1
    
    def _handle_user_creation(self, command, result):
        """Handle Windows user account creation"""
        username = command.get('username')
        password = command.get('password')
        full_name = command.get('full_name', '')
        description = command.get('description', '')
        is_admin = command.get('is_admin', False)
        
        logger.info("=" * 70)
        logger.info(f"👤 CREATING USER: {username}")
        logger.info("=" * 70)
        
        try:
            # Step 1: Create user account
            create_cmd = f'net user {username} {password} /add'
            if full_name:
                create_cmd += f' /fullname:"{full_name}"'
            if description:
                create_cmd += f' /comment:"{description}"'
            
            logger.info(f"📋 Creating user account...")
            
            # Check if running as admin (using renamed function to avoid conflict)
            if not check_is_running_as_admin():
                raise Exception("Client must be running as Administrator to create users. Please restart with 'Run as Administrator'.")
            
            # Use cmd.exe directly for better elevation handling
            proc = subprocess.run(
                ["cmd.exe", "/c", create_cmd],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if proc.returncode != 0:
                raise Exception(f"User creation failed: {proc.stderr}")
            
            logger.info(f"✅ User account created: {username}")
            
            # Step 2: Add to Administrators group if requested
            if is_admin:
                logger.info(f"🔐 Adding {username} to Administrators group...")
                admin_cmd = f'net localgroup Administrators {username} /add'
                proc = subprocess.run(
                    admin_cmd,
                    shell=True,
                    capture_output=True,
                    text=True
                )
                
                if proc.returncode == 0:
                    logger.info(f"✅ {username} added to Administrators")
                else:
                    logger.warning(f"⚠️  Could not add to Administrators: {proc.stderr}")
            
            logger.info("=" * 70)
            logger.info("✨ USER CREATION SUCCESSFUL!")
            logger.info("=" * 70)
            
            result['status'] = 'success'
            result['exit_code'] = 0
            
        except Exception as e:
            logger.error("=" * 70)
            logger.error(f"❌ USER CREATION FAILED")
            logger.error("=" * 70)
            logger.error(f"Error: {e}")
            result['status'] = 'failed'
            result['exit_code'] = -1
            result['error_message'] = str(e)
    
    def _handle_user_deletion(self, command, result):
        """Handle Windows user account deletion"""
        username = command.get('username')
        
        logger.info("=" * 70)
        logger.info(f"🗑️  DELETING USER: {username}")
        logger.info("=" * 70)
        
        try:
            # Delete user account
            delete_cmd = f'net user {username} /delete'
            
            logger.info(f"📋 Deleting user account...")
            proc = subprocess.run(
                delete_cmd,
                shell=True,
                capture_output=True,
                text=True
            )
            
            if proc.returncode == 0:
                logger.info("=" * 70)
                logger.info("✨ USER DELETION SUCCESSFUL!")
                logger.info("=" * 70)
                result['status'] = 'success'
                result['exit_code'] = 0
            else:
                raise Exception(f"User deletion failed: {proc.stderr}")
        
        except Exception as e:
            logger.error("=" * 70)
            logger.error(f"❌ USER DELETION FAILED")
            logger.error("=" * 70)
            logger.error(f"Error: {e}")
            result['status'] = 'failed'
            result['exit_code'] = -1
            result['error_message'] = str(e)
    
    def _run_wmic_inventory(self):
        """
        WMIC-based software + hardware inventory collection
        THE GOLDMINE!
        """
        if not self.credential_vault.has_credentials():
            logger.warning("⚠️  No credentials available for WMIC inventory!")
            return
        
        logger.info("\n" + "=" * 70)
        logger.info("🔍 STARTING FULL SYSTEM INVENTORY (Software + Hardware)")
        logger.info("=" * 70)
        
        auth_flags = self.credential_vault.get_auth_flags()
        
        inventory_data = {
            'software': [],
            'hardware': {}
        }
        
        try:
            # 1. SOFTWARE INVENTORY
            logger.info("📦 Scanning installed software...")
            wmic_cmd = f'wmic {auth_flags} product get Name,Version,Vendor,InstallDate /format:csv'
            
            result = subprocess.run(
                wmic_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode == 0:
                software_list = self._parse_wmic_csv(result.stdout)
                inventory_data['software'] = software_list
                logger.info(f"✅ Found {len(software_list)} software packages")
            else:
                logger.error(f"❌ WMIC software scan failed: {result.stderr}")
            
            # 2. HARDWARE: CPU
            logger.info("🔍 Scanning CPU...")
            cpu_cmd = f'wmic {auth_flags} cpu get Name,NumberOfCores /format:csv'
            cpu_result = subprocess.run(
                cpu_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if cpu_result.returncode == 0:
                for line in cpu_result.stdout.split('\n'):
                    if line.strip() and not line.startswith('Node'):
                        parts = line.split(',')
                        if len(parts) >= 3:
                            cpu_name = parts[1].strip()
                            cpu_cores = parts[2].strip()
                            inventory_data['hardware']['cpu'] = f"{cpu_name} ({cpu_cores} cores)"
                        elif len(parts) >= 2:
                            inventory_data['hardware']['cpu'] = parts[-1].strip()
                        else:
                            inventory_data['hardware']['cpu'] = "Unknown CPU"
            
            # 3. HARDWARE: RAM
            logger.info("🔍 Scanning RAM...")
            ram_cmd = f'wmic {auth_flags} computersystem get TotalPhysicalMemory /format:csv'
            ram_result = subprocess.run(
                ram_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if ram_result.returncode == 0:
                for line in ram_result.stdout.split('\n'):
                    if line.strip() and not line.startswith('Node'):
                        parts = line.split(',')
                        bytes_val = parts[-1].strip()
                        try:
                            gb_val = round(int(bytes_val) / (1024**3), 1)
                            inventory_data['hardware']['ram'] = f"{gb_val} GB"
                        except:
                            inventory_data['hardware']['ram'] = "Unknown"
                        break
            
            # 4. HARDWARE: DISK C:
            logger.info("🔍 Scanning Disk (C:)...")
            disk_cmd = f'wmic {auth_flags} logicaldisk where "DeviceID=\'C:\'" get Size,FreeSpace /format:csv'
            disk_result = subprocess.run(
                disk_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if disk_result.returncode == 0:
                for line in disk_result.stdout.split('\n'):
                    if line.strip() and not line.startswith('Node'):
                        parts = line.split(',')
                        if len(parts) >= 3:
                            try:
                                free_bytes = int(parts[1].strip())
                                total_bytes = int(parts[2].strip())
                                free_gb = round(free_bytes / (1024**3), 1)
                                total_gb = round(total_bytes / (1024**3), 1)
                                free_pct = round((free_bytes / total_bytes) * 100, 1)
                                inventory_data['hardware']['disk'] = f"{total_gb}GB Total ({free_gb}GB Free, {free_pct}%)"
                            except:
                                inventory_data['hardware']['disk'] = "Unknown"
                            break
            
            # Display hardware findings
            logger.info("\n📊 HARDWARE DETECTED:")
            logger.info(f"   CPU:  {inventory_data['hardware'].get('cpu', 'N/A')}")
            logger.info(f"   RAM:  {inventory_data['hardware'].get('ram', 'N/A')}")
            logger.info(f"   Disk: {inventory_data['hardware'].get('disk', 'N/A')}")
            
            # Show software sample
            if inventory_data['software']:
                logger.info("\n📦 Software Sample (first 5):")
                for sw in inventory_data['software'][:5]:
                    logger.info(f"   • {sw['name']} ({sw['version']}) - {sw['vendor']}")
                if len(inventory_data['software']) > 5:
                    logger.info(f"   ... and {len(inventory_data['software']) - 5} more")
            
            # Send ALL data to server
            logger.info("\n📤 Sending complete inventory to server...")
            self._send_inventory_to_server(inventory_data)
            
            logger.info("=" * 70)
            logger.info("✅ FULL SYSTEM INVENTORY COMPLETE!")
            logger.info("=" * 70)
            
        except subprocess.TimeoutExpired:
            logger.error("❌ WMIC query timed out")
        except Exception as e:
            logger.error(f"❌ Inventory failed: {e}")
    
    def _parse_wmic_csv(self, csv_output: str) -> list:
        """Parse WMIC CSV output into software list"""
        software_list = []
        
        lines = csv_output.strip().split('\n')
        
        if len(lines) < 2:
            return software_list
        
        # First line is headers
        headers = [h.strip() for h in lines[0].split(',')]
        
        # Find column indices
        try:
            name_idx = headers.index('Name')
            version_idx = headers.index('Version') if 'Version' in headers else None
            vendor_idx = headers.index('Vendor') if 'Vendor' in headers else None
            install_date_idx = headers.index('InstallDate') if 'InstallDate' in headers else None
        except ValueError:
            logger.error("❌ Could not find required columns in WMIC output")
            return software_list
        
        # Parse data rows
        for line in lines[1:]:
            line = line.strip()
            if not line or line.startswith('Node,'):
                continue
            
            parts = line.split(',')
            
            if len(parts) <= name_idx:
                continue
            
            # Skip if name is empty
            name = parts[name_idx].strip() if name_idx < len(parts) else ''
            if not name:
                continue
            
            software = {
                'name': name,
                'version': parts[version_idx].strip() if version_idx and version_idx < len(parts) else 'Unknown',
                'vendor': parts[vendor_idx].strip() if vendor_idx and vendor_idx < len(parts) else 'Unknown',
                'install_date': parts[install_date_idx].strip() if install_date_idx and install_date_idx < len(parts) else ''
            }
            
            software_list.append(software)
        
        return software_list
    
    def _send_inventory_to_server(self, inventory_data: dict):
        """Send collected inventory back to server"""
        inventory_report = {
            'type': 'inventory_report',
            'inventory': {
                'software': inventory_data.get('software', []),
                'hardware': inventory_data.get('hardware', {}),
                'scan_timestamp': datetime.now().isoformat(),
                'client_id': self.client_id,
                'hostname': self.system_info['hostname']
            }
        }
        
        try:
            # Convert to JSON
            
            # Send to server (using framed send)
            send_json_line(self.socket, inventory_report)
            
            # Wait for acknowledgment (using framed receive)
            buffer = bytearray()
            for ack in recv_json_lines(self.socket, buffer):
                break  # Get first message
            
            if ack.get('status') == 'ok':
                logger.info("✅ Server acknowledged inventory receipt!")
            else:
                logger.warning(f"⚠️  Server response: {ack}")
                
        except Exception as e:
            logger.error(f"❌ Failed to send inventory to server: {e}")

    def _heartbeat_loop(self):
        """Send keep-alive to server"""
        heartbeat_interval = CONFIG.get('heartbeat_interval', 30)
        
        while self.running:
            time.sleep(heartbeat_interval)

            # V6: Skip heartbeat if file transfer in progress
            if self.transfer_in_progress:
                continue
            try:
                hb = {'type': 'heartbeat', 'client_id': self.client_id}
                send_json_line(self.socket, hb)
            except:
                self.running = False
                break
    
    def show_local_menu(self):
        """Show local client menu for VPN and status"""
        print("\n" + "="*70)
        print("N2NHU AGENT - LOCAL MENU")
        print("="*70)
        print("\n🔧 LOCAL OPTIONS:")
        print("  1. VPN Status")
        print("  2. Start VPN Connection")
        print("  3. Stop VPN Connection")
        print("  4. View System Info")
        print("  5. Return to Server Connection")
        print("\nSelect option (1-5): ", end='')
    
    def local_menu_loop(self):
        """Interactive local menu"""
        while True:
            self.show_local_menu()
            
            try:
                choice = input().strip()
                
                if choice == '1':
                    print(f"\n🔌 VPN Status: {self.vpn_manager.status()}")
                elif choice == '2':
                    self.vpn_manager.start_vpn()
                elif choice == '3':
                    self.vpn_manager.stop_vpn()
                elif choice == '4':
                    print("\n📊 System Information:")
                    for key, value in self.system_info.items():
                        print(f"   {key}: {value}")
                elif choice == '5':
                    print("\n↩️  Returning to server connection mode...")
                    break
                else:
                    print("Invalid option. Please try again.")
                
                input("\nPress Enter to continue...")
                
            except KeyboardInterrupt:
                print("\n\n↩️  Returning to server connection mode...")
                break



    def handle_enhanced_package_deploy(self, message: dict):
        """V9 ENHANCED: Chunked file transfer with SHA256 on SEPARATE TRANSFER SOCKET"""
        transfer_sock = None
        try:
            # V6: Pause heartbeat during file transfer
            self.transfer_in_progress = True

            package_name = message.get('package_name', 'Unknown')
            transfer_id = message.get('transfer_id')
            transfer_port = message.get('transfer_port', 2223)  # V8: Get transfer port
            transfer_token = message.get('transfer_token')  # V9: Security token
            
            logger.info("\n" + "="*70)
            logger.info("📦 ENHANCED DEPLOYMENT V9 (Separate Transfer Socket)")
            logger.info("="*70)
            logger.info(f"Package: {package_name}")
            logger.info(f"Transfer ID: {transfer_id}")
            logger.info(f"Transfer Port: {transfer_port}")
            
            # V8: Connect to TRANSFER socket (separate from control)
            logger.info(f"🔌 Connecting to transfer channel {self.host}:{transfer_port}...")
            transfer_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # V9: Set timeout to prevent hanging forever
            transfer_sock.settimeout(600)  # 10 minutes max for entire transfer
            transfer_sock.connect((self.host, transfer_port))
            
            # V8: Send transfer hello (length-prefixed JSON)
            hello = {
                'type': 'transfer_hello',
                'client_id': self.client_id,
                'transfer_id': transfer_id,
                'transfer_token': transfer_token  # V9: Security token
            }
            send_lp_json(transfer_sock, hello)
            logger.info("✅ Transfer channel connected")
            
            # V8: Receive file on TRANSFER socket (not control socket!)
            staging_dir = CONFIG.get('staging_dir') or os.path.join(os.getenv('TEMP', 'C:\\Temp'), 'N2NHU_Staging')
            receiver = ChunkedFileReceiver(transfer_sock, staging_dir=staging_dir)  # V8: Use transfer socket!
            
            logger.info("📥 Receiving on transfer channel...")
            received_file = receiver.receive_file()
            
            # V8: Close transfer socket after file received
            transfer_sock.close()
            transfer_sock = None
            logger.info("📦 Transfer channel closed")
            
            if not received_file:
                logger.error("❌ Transfer failed")
                # V8: Report on CONTROL socket
                send_json_line(self.socket, {'status': 'failed', 'transfer_id': transfer_id, 'error': 'Transfer failed'})
                return
            
            logger.info(f"✅ Received: {format_bytes(os.path.getsize(received_file))}")
            logger.info("✓ SHA256 verified")
            
            # Install (unchanged)
            logger.info("🚀 Installing...")
            success, exit_code, error_msg = self._execute_msi_installer(received_file)
            
            # V8: Report results on CONTROL socket (self.socket, not transfer_sock!)
            if success:
                logger.info("✨ Install complete!")
                send_json_line(self.socket, {'status': 'installed', 'exit_code': exit_code, 'transfer_id': transfer_id})
                if CONFIG.get('cleanup_after_install', False):
                    try:
                        os.remove(received_file)
                    except:
                        pass
            else:
                logger.error(f"❌ Install failed: {error_msg}")
                send_json_line(self.socket, {'status': 'failed', 'error': error_msg, 'exit_code': exit_code, 'transfer_id': transfer_id})
            
            logger.info("="*70)
        except Exception as e:
            logger.error(f"❌ Error: {e}")
            try:
                # V8: Report error on CONTROL socket
                send_json_line(self.socket, {'status': 'failed', 'transfer_id': message.get('transfer_id'), 'error': str(e)})
            except:
                pass
        finally:
            # V8: Always close transfer socket if still open
            if transfer_sock:
                try:
                    transfer_sock.close()
                except:
                    pass
            
            # V6: Always clear flag when transfer completes
            self.transfer_in_progress = False
            logger.info("🔓 Transfer complete - heartbeat resumed")


    def _execute_msi_installer(self, msi_path: str) -> tuple:
        """Execute MSI installer. Returns (success, exit_code, error_msg)"""
        try:
            cmd = ['msiexec.exe', '/i', msi_path, '/quiet', '/norestart', '/l*v', msi_path + '.log']
            logger.info(f"📋 Command: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
            
            exit_code = result.returncode
            if exit_code in [0, 3010]:  # Success or success with reboot
                logger.info(f"✅ Exit code: {exit_code}")
                return (True, exit_code, None)
            else:
                error_msg = f"Exit code {exit_code}"
                logger.error(f"❌ {error_msg}")
                return (False, exit_code, error_msg)
        except subprocess.TimeoutExpired:
            return (False, -1, "Timeout after 10 minutes")
        except Exception as e:
            return (False, -1, str(e))


if __name__ == "__main__":
    print("""
    ╔══════════════════════════════════════════════════════════════════╗
    ║       N2NHU NETWORK MANAGEMENT AGENT - V4 ENHANCED               ║
    ║    The "Player" that executes Server Transformations             ║
    ║                                                                  ║
    ║    V3 ENHANCEMENTS:                                              ║
    ║    • Complete Hardware Inventory (CPU, RAM, Disk)                ║
    ║    • Software Inventory (with credentials)                       ║
    ║    • MSI Package Deployment (Stage & Execute)                    ║
    ║    • Windows User Account Management                             ║
    ║    • Software Uninstallation                                     ║
    ║    • Integrated VPN Client                                       ║
    ║                                                                  ║
    ║    THE COMPLETE GOLDMINE IS READY! 💰                            ║
    ║                                                                  ║
    ╚══════════════════════════════════════════════════════════════════╝
    """)
    
    # Auto-target localhost for demo
    agent = NetworkAgent(SERVER_HOST, SERVER_PORT)
    
    # Show local menu first (for VPN control)
    print("\n⚠️  Starting in LOCAL MENU mode...")
    print("   Use option 5 to connect to server")
    
    agent.local_menu_loop()
    
    # After local menu, connect to server
    agent.connect()
