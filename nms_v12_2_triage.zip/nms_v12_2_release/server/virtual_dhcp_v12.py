"""Virtual DHCP Server for VPN Client IP Allocation - V12 GOLDEN MASTER"""

import sqlite3
from datetime import datetime
import ipaddress
import time

class VirtualDHCPServer:
    """Virtual DHCP server for VPN client IP allocation"""
    
    def __init__(self, db_path='network_mgmt.db'):
        self.db_path = db_path
        self.config = {}
        self.leases = {}
        # V12: SQLite connection timeout to prevent "database is locked"
        self.db_timeout = 30  # 30 seconds
        self.init_database()
        self.load_config()
    
    def init_database(self):
        """Initialize database tables"""
        conn = sqlite3.connect(self.db_path, timeout=self.db_timeout)
        c = conn.cursor()
        
        # DHCP configuration table
        c.execute('''CREATE TABLE IF NOT EXISTS dhcp_config (
            id INTEGER PRIMARY KEY,
            enabled BOOLEAN,
            interface_name TEXT,
            network TEXT,
            subnet_mask TEXT,
            gateway TEXT,
            pool_start TEXT,
            pool_end TEXT,
            dns_servers TEXT
        )''')
        
        # VPN clients table
        c.execute('''CREATE TABLE IF NOT EXISTS vpn_clients (
            client_id TEXT PRIMARY KEY,
            hostname TEXT,
            vpn_ip TEXT,
            mac_address TEXT,
            wan_ip TEXT,
            connected_at TIMESTAMP,
            last_seen TIMESTAMP,
            status TEXT,
            lease_expires TIMESTAMP
        )''')
        
        conn.commit()
        conn.close()
    
    def load_config(self):
        """Load DHCP configuration from database"""
        conn = sqlite3.connect(self.db_path, timeout=self.db_timeout)
        c = conn.cursor()
        
        c.execute('SELECT * FROM dhcp_config WHERE id = 1')
        row = c.fetchone()
        
        if row:
            self.config = {
                'enabled': bool(row[1]),
                'interface_name': row[2],
                'network': row[3],
                'subnet_mask': row[4],
                'gateway': row[5],
                'pool_start': row[6],
                'pool_end': row[7],
                'dns_servers': row[8].split(',') if row[8] else []
            }
        else:
            # Default configuration
            self.config = {
                'enabled': False,
                'interface_name': 'Ethernet1',
                'network': '192.168.1.0',
                'subnet_mask': '255.255.255.0',
                'gateway': '192.168.1.1',
                'pool_start': '192.168.1.150',
                'pool_end': '192.168.1.200',
                'dns_servers': ['192.168.1.10', '192.168.1.11']
            }
        
        conn.close()
    
    def save_config(self):
        """Save DHCP configuration to database"""
        # V12: Validate configuration before saving
        self._validate_config()
        
        conn = sqlite3.connect(self.db_path, timeout=self.db_timeout)
        c = conn.cursor()
        
        c.execute('''INSERT OR REPLACE INTO dhcp_config 
                     (id, enabled, interface_name, network, subnet_mask, gateway, pool_start, pool_end, dns_servers)
                     VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)''',
                  (self.config['enabled'],
                   self.config['interface_name'],
                   self.config['network'],
                   self.config['subnet_mask'],
                   self.config['gateway'],
                   self.config['pool_start'],
                   self.config['pool_end'],
                   ','.join(self.config['dns_servers'])))
        
        conn.commit()
        conn.close()
    
    def _validate_config(self):
        """V12: Validate DHCP configuration for consistency"""
        try:
            # Parse network and subnet
            network = ipaddress.IPv4Network(
                f"{self.config['network']}/{self.config['subnet_mask']}", 
                strict=False
            )
            
            # Validate pool range
            pool_start = ipaddress.IPv4Address(self.config['pool_start'])
            pool_end = ipaddress.IPv4Address(self.config['pool_end'])
            
            # Check pool is within network
            if pool_start not in network or pool_end not in network:
                raise ValueError("DHCP pool must be within network subnet")
            
            # Check pool start <= end
            if int(pool_end) < int(pool_start):
                raise ValueError("DHCP pool_end must be >= pool_start")
            
            # Validate gateway is in same subnet
            if self.config.get('gateway'):
                gateway = ipaddress.IPv4Address(self.config['gateway'])
                if gateway not in network:
                    raise ValueError("Gateway must be within network subnet")
            
            return True
            
        except Exception as e:
            raise ValueError(f"DHCP configuration validation failed: {e}")
    
    def _parse_pool(self):
        """V12: Parse pool_start/pool_end into candidate IP range."""
        start = ipaddress.ip_address(self.config['pool_start'])
        end = ipaddress.ip_address(self.config['pool_end'])
        if int(end) < int(start):
            raise ValueError("DHCP pool_end must be >= pool_start")
        return start, end

    def _cleanup_expired_leases(self, c, now_iso: str) -> None:
        """
        V12: Reclaim expired leases WITHOUT deleting client history.
        
        Sets status to 'EXPIRED' and clears vpn_ip, preserving the client record
        for audit/history purposes.
        """
        c.execute(
            """UPDATE vpn_clients 
               SET status = 'EXPIRED', vpn_ip = NULL 
               WHERE lease_expires IS NOT NULL 
               AND lease_expires < ? 
               AND status = 'ONLINE'""",
            (now_iso,),
        )

    def _find_free_ip_locked(self, c) -> str:
        """V12: Find a free IP inside the configured pool. Caller must hold DB write lock."""
        start, end = self._parse_pool()

        # V12: Only consider IPs that are actively allocated (not EXPIRED/OFFLINE)
        c.execute(
            "SELECT vpn_ip FROM vpn_clients WHERE vpn_ip IS NOT NULL AND status = 'ONLINE'"
        )
        allocated = {r[0] for r in c.fetchall() if r and r[0]}

        for ip_int in range(int(start), int(end) + 1):
            ip = str(ipaddress.ip_address(ip_int))
            if ip not in allocated:
                return ip

        raise Exception("DHCP pool exhausted!")

    def allocate_ip(self, client_id):
        """
        V12: Allocate (or return) an IP address from the pool.

        NOTE: This function does NOT persist a lease. For concurrency-safe behavior,
        use register_client(), which allocates + persists atomically.
        """
        conn = sqlite3.connect(self.db_path, timeout=self.db_timeout)
        try:
            c = conn.cursor()

            # Return existing lease if present and ONLINE
            c.execute(
                "SELECT vpn_ip FROM vpn_clients WHERE client_id = ? AND status = 'ONLINE'", 
                (client_id,)
            )
            row = c.fetchone()
            if row and row[0]:
                return row[0]

            # Best-effort allocation (non-persistent) under a write lock to reduce races
            now_iso = datetime.now().isoformat()
            self._begin_immediate_with_retry(c, conn)
            self._cleanup_expired_leases(c, now_iso)
            ip = self._find_free_ip_locked(c)
            conn.commit()
            print(f"[DHCP] (non-persistent) Allocated {ip} to {client_id}")
            return ip
        finally:
            conn.close()

    def _begin_immediate_with_retry(self, cursor, conn, max_retries=3):
        """V12: BEGIN IMMEDIATE with retry logic for high load"""
        for attempt in range(max_retries):
            try:
                cursor.execute("BEGIN IMMEDIATE")
                return
            except sqlite3.OperationalError as e:
                if "locked" in str(e).lower() and attempt < max_retries - 1:
                    # Database locked, retry after short delay
                    time.sleep(0.1 * (attempt + 1))  # Exponential backoff
                    continue
                else:
                    raise

    def register_client(self, client_id, hostname, mac_address, wan_ip):
        """
        V12: Register/update VPN client and allocate IP atomically.

        This is the correct production path: allocation + persistence happen under
        a DB write lock so two clients cannot receive the same IP.
        """
        conn = sqlite3.connect(self.db_path, timeout=self.db_timeout)
        try:
            c = conn.cursor()
            now_iso = datetime.now().isoformat()

            # V12: Acquire write lock with retry
            self._begin_immediate_with_retry(c, conn)

            # V12: Reclaim expired leases before allocating (preserves history)
            self._cleanup_expired_leases(c, now_iso)

            # Reuse existing lease if any and still ONLINE
            c.execute(
                "SELECT vpn_ip FROM vpn_clients WHERE client_id = ? AND status = 'ONLINE'", 
                (client_id,)
            )
            row = c.fetchone()
            if row and row[0]:
                vpn_ip = row[0]
                print(f"[DHCP] Renewed lease {vpn_ip} for {client_id}")
            else:
                # V12: Atomic allocation under DB lock
                vpn_ip = self._find_free_ip_locked(c)
                print(f"[DHCP] Allocated {vpn_ip} to {client_id}")

            # 24h lease
            lease_expires_iso = datetime.fromtimestamp(
                datetime.now().timestamp() + 86400
            ).isoformat()

            c.execute(
                """INSERT OR REPLACE INTO vpn_clients
                   (client_id, hostname, vpn_ip, mac_address, wan_ip, connected_at, last_seen, status, lease_expires)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (client_id, hostname, vpn_ip, mac_address, wan_ip, now_iso, now_iso, 'ONLINE', lease_expires_iso)
            )

            conn.commit()
            return vpn_ip
        finally:
            conn.close()
    
    def generate_config(self, client_id, vpn_ip):
        """Generate VPN configuration for client"""
        return {
            'vpn_ip': vpn_ip,
            'subnet_mask': self.config['subnet_mask'],
            'gateway': self.config['gateway'],
            'network': self.config['network'],
            'dns_servers': self.config['dns_servers']
        }
    
    def get_active_clients(self):
        """Get list of active VPN clients"""
        conn = sqlite3.connect(self.db_path, timeout=self.db_timeout)
        c = conn.cursor()
        
        c.execute("""SELECT client_id, hostname, vpn_ip, wan_ip, connected_at, status 
                     FROM vpn_clients 
                     WHERE status = 'ONLINE'
                     ORDER BY connected_at DESC""")
        
        clients = c.fetchall()
        conn.close()
        return clients
    
    def update_client_status(self, client_id, status):
        """Update client status"""
        conn = sqlite3.connect(self.db_path, timeout=self.db_timeout)
        c = conn.cursor()
        
        now = datetime.now().isoformat()
        
        c.execute("""UPDATE vpn_clients 
                     SET status = ?, last_seen = ? 
                     WHERE client_id = ?""",
                  (status, now, client_id))
        
        conn.commit()
        conn.close()
