"""Network Adapter Utilities for DHCP Configuration"""

import subprocess
import platform
import re

def list_network_adapters():
    """List all network adapters on the system"""
    adapters = []
    system = platform.system()
    
    if system == 'Windows':
        try:
            # Use ipconfig to list adapters
            result = subprocess.run(['ipconfig', '/all'], 
                                  capture_output=True, 
                                  text=True, 
                                  encoding='cp1252')  # Windows console encoding
            
            current_adapter = None
            current_ip = None
            current_status = 'Unknown'
            
            for line in result.stdout.split('\n'):
                # New adapter section
                if 'adapter' in line.lower() and ':' in line:
                    if current_adapter:
                        adapters.append({
                            'name': current_adapter,
                            'ip': current_ip or 'Not configured',
                            'status': current_status
                        })
                    
                    # Extract adapter name
                    current_adapter = line.split(':')[0].strip()
                    current_adapter = current_adapter.replace('Ethernet adapter ', '')
                    current_adapter = current_adapter.replace('Wireless LAN adapter ', '')
                    current_ip = None
                    current_status = 'Unknown'
                
                # Get IP address
                if 'IPv4 Address' in line and current_adapter:
                    ip_match = re.search(r'(\d+\.\d+\.\d+\.\d+)', line)
                    if ip_match:
                        current_ip = ip_match.group(1)
                        current_status = 'Active'
                
                # Check if disconnected
                if 'Media disconnected' in line or 'Media State' in line:
                    current_status = 'Disconnected'
            
            # Add last adapter
            if current_adapter:
                adapters.append({
                    'name': current_adapter,
                    'ip': current_ip or 'Not configured',
                    'status': current_status
                })
                
        except Exception as e:
            print(f"Error listing Windows adapters: {e}")
            
    elif system == 'Linux':
        try:
            # Use ip addr show
            result = subprocess.run(['ip', 'addr', 'show'], 
                                  capture_output=True, 
                                  text=True)
            
            current_adapter = None
            current_ip = None
            
            for line in result.stdout.split('\n'):
                # New interface
                if line and line[0].isdigit():
                    if current_adapter:
                        adapters.append({
                            'name': current_adapter,
                            'ip': current_ip or 'Not configured',
                            'status': 'Active' if current_ip else 'Unknown'
                        })
                    
                    parts = line.split(':')
                    if len(parts) >= 2:
                        current_adapter = parts[1].strip()
                        current_ip = None
                
                # Get IP
                if 'inet ' in line and current_adapter:
                    ip_match = re.search(r'inet (\d+\.\d+\.\d+\.\d+)', line)
                    if ip_match:
                        current_ip = ip_match.group(1)
            
            # Add last adapter
            if current_adapter:
                adapters.append({
                    'name': current_adapter,
                    'ip': current_ip or 'Not configured',
                    'status': 'Active' if current_ip else 'Unknown'
                })
                
        except Exception as e:
            print(f"Error listing Linux adapters: {e}")
    
    return adapters

def get_adapter_network(adapter_ip):
    """Get network address from adapter IP"""
    if not adapter_ip or adapter_ip == 'Not configured':
        return None
    
    try:
        # Assume /24 subnet for simplicity
        octets = adapter_ip.split('.')
        network = f"{octets[0]}.{octets[1]}.{octets[2]}.0"
        return network
    except:
        return None

def suggest_ip_pool(network_address):
    """Suggest IP pool range based on network"""
    if not network_address:
        return None, None
    
    try:
        octets = network_address.split('.')
        # Suggest pool in upper range to avoid DHCP conflicts
        pool_start = f"{octets[0]}.{octets[1]}.{octets[2]}.150"
        pool_end = f"{octets[0]}.{octets[1]}.{octets[2]}.200"
        return pool_start, pool_end
    except:
        return None, None

def validate_ip(ip_str):
    """Validate IP address format"""
    try:
        parts = ip_str.split('.')
        if len(parts) != 4:
            return False
        for part in parts:
            num = int(part)
            if num < 0 or num > 255:
                return False
        return True
    except:
        return False
