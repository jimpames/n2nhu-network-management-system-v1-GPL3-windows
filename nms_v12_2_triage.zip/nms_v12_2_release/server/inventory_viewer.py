#!/usr/bin/env python3
"""
N2NHU Database Inventory Viewer
Interactive browser for software and hardware inventory
"""

import sqlite3
import os
import sys
from datetime import datetime

class InventoryViewer:
    def __init__(self, db_path="network_management.db"):
        self.db_path = db_path
        if not os.path.exists(db_path):
            print(f"❌ Database not found: {db_path}")
            print(f"   Current directory: {os.getcwd()}")
            print(f"   Please run from server directory or specify path")
            sys.exit(1)
        
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
    
    def get_summary(self):
        """Get database summary statistics"""
        cursor = self.conn.cursor()
        
        # Total clients
        cursor.execute("SELECT COUNT(*) FROM clients")
        total_clients = cursor.fetchone()[0]
        
        # Total software records
        cursor.execute("SELECT COUNT(*) FROM software_inventory")
        total_software = cursor.fetchone()[0]
        
        # Unique software titles
        cursor.execute("SELECT COUNT(DISTINCT software_name) FROM software_inventory")
        unique_software = cursor.fetchone()[0]
        
        # Clients with inventory
        cursor.execute("""
            SELECT COUNT(DISTINCT client_id) 
            FROM software_inventory 
            WHERE software_name IS NOT NULL
        """)
        clients_with_inventory = cursor.fetchone()[0]
        
        # Latest scan
        cursor.execute("""
            SELECT MAX(scan_timestamp) FROM software_inventory
        """)
        latest_scan = cursor.fetchone()[0]
        
        return {
            'total_clients': total_clients,
            'total_software': total_software,
            'unique_software': unique_software,
            'clients_with_inventory': clients_with_inventory,
            'latest_scan': latest_scan
        }
    
    def list_clients(self):
        """List all clients with inventory counts"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT 
                c.hostname,
                c.cpu_info,
                c.ram_info,
                c.disk_info,
                COUNT(s.id) as software_count,
                MAX(s.scan_timestamp) as last_scan
            FROM clients c
            LEFT JOIN software_inventory s ON c.client_id = s.client_id
            GROUP BY c.hostname
            ORDER BY c.hostname
        """)
        return cursor.fetchall()
    
    def get_client_software(self, hostname, page=0, page_size=20):
        """Get software for a specific client (paginated)"""
        cursor = self.conn.cursor()
        offset = page * page_size
        
        # Get total count
        cursor.execute("""
            SELECT COUNT(*) FROM software_inventory 
            WHERE client_id = (SELECT client_id FROM clients WHERE hostname = ?)
        """, (hostname,))
        total = cursor.fetchone()[0]
        
        # Get page of results
        cursor.execute("""
            SELECT 
                software_name,
                software_version as version,
                vendor,
                install_date,
                scan_timestamp as scanned_at
            FROM software_inventory
            WHERE client_id = (SELECT client_id FROM clients WHERE hostname = ?)
            ORDER BY software_name
            LIMIT ? OFFSET ?
        """, (hostname, page_size, offset))
        
        results = cursor.fetchall()
        total_pages = (total + page_size - 1) // page_size
        
        return results, total, total_pages
    
    def search_software(self, search_term, page=0, page_size=20):
        """Search for software by name"""
        cursor = self.conn.cursor()
        offset = page * page_size
        search_pattern = f"%{search_term}%"
        
        # Get total count
        cursor.execute("""
            SELECT COUNT(*) FROM software_inventory 
            WHERE software_name LIKE ? OR vendor LIKE ?
        """, (search_pattern, search_pattern))
        total = cursor.fetchone()[0]
        
        # Get page of results
        cursor.execute("""
            SELECT 
                c.hostname,
                s.software_name,
                s.software_version as version,
                s.vendor,
                s.install_date
            FROM software_inventory s
            JOIN clients c ON s.client_id = c.client_id
            WHERE s.software_name LIKE ? OR s.vendor LIKE ?
            ORDER BY c.hostname, s.software_name
            LIMIT ? OFFSET ?
        """, (search_pattern, search_pattern, page_size, offset))
        
        results = cursor.fetchall()
        total_pages = (total + page_size - 1) // page_size
        
        return results, total, total_pages
    
    def get_software_distribution(self, software_name):
        """Show which clients have a specific software"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT 
                c.hostname,
                s.software_version as version,
                s.vendor,
                s.install_date,
                s.scan_timestamp as scanned_at
            FROM software_inventory s
            JOIN clients c ON s.client_id = c.client_id
            WHERE s.software_name = ?
            ORDER BY c.hostname
        """, (software_name,))
        return cursor.fetchall()
    
    def display_summary(self):
        """Display database summary"""
        stats = self.get_summary()
        
        print("\n" + "="*70)
        print("📊 N2NHU INVENTORY DATABASE SUMMARY")
        print("="*70)
        print(f"\n📁 Database: {self.db_path}")
        print(f"🖥️  Total Clients: {stats['total_clients']}")
        print(f"📦 Total Software Records: {stats['total_software']:,}")
        print(f"🔢 Unique Software Titles: {stats['unique_software']:,}")
        print(f"✅ Clients with Inventory: {stats['clients_with_inventory']}")
        if stats['latest_scan']:
            print(f"🕐 Latest Scan: {stats['latest_scan']}")
        print("="*70)
    
    def interactive_menu(self):
        """Main interactive menu"""
        while True:
            print("\n" + "="*70)
            print("N2NHU INVENTORY VIEWER - MAIN MENU")
            print("="*70)
            print("\n📋 OPTIONS:")
            print("  1. Show Summary")
            print("  2. List All Clients")
            print("  3. View Client Software (by hostname)")
            print("  4. Search Software (by name/vendor)")
            print("  5. Find Software Distribution (where is X installed?)")
            print("  6. Export to CSV")
            print("  Q. Quit")
            
            choice = input("\nSelect option (1-6, Q): ").strip().upper()
            
            if choice == 'Q':
                print("\n👋 Goodbye!")
                break
            elif choice == '1':
                self.display_summary()
            elif choice == '2':
                self.display_clients()
            elif choice == '3':
                self.view_client_software_interactive()
            elif choice == '4':
                self.search_software_interactive()
            elif choice == '5':
                self.find_software_distribution()
            elif choice == '6':
                self.export_to_csv()
            else:
                print("❌ Invalid option. Please try again.")
            
            input("\nPress Enter to continue...")
    
    def display_clients(self):
        """Display all clients with software counts"""
        clients = self.list_clients()
        
        print("\n" + "="*120)
        print("🖥️  CLIENT INVENTORY SUMMARY")
        print("="*120)
        print(f"\n{'Hostname':<20} {'CPU':<35} {'RAM':<12} {'Disk':<20} {'Software':<10} {'Last Scan'}")
        print("-"*120)
        
        for client in clients:
            hostname = client['hostname'] or 'N/A'
            cpu = client['cpu_info'] or 'N/A'
            ram = client['ram_info'] or 'N/A'
            disk = client['disk_info'] or 'N/A'
            count = client['software_count'] or 0
            scan = client['last_scan'] or 'Never'
            
            # Truncate long fields
            cpu = (cpu[:32] + '...') if len(cpu) > 35 else cpu
            
            print(f"{hostname:<20} {cpu:<35} {ram:<12} {disk:<20} {count:<10} {scan}")
        
        print("-"*120)
        print(f"Total Clients: {len(clients)}")
    
    def view_client_software_interactive(self):
        """Interactive client software viewer"""
        hostname = input("\nEnter hostname (or part of it): ").strip()
        
        if not hostname:
            print("❌ Hostname required")
            return
        
        # Try exact match first
        cursor = self.conn.cursor()
        cursor.execute("SELECT hostname FROM clients WHERE hostname = ?", (hostname,))
        result = cursor.fetchone()
        
        # If not found, try partial match
        if not result:
            cursor.execute("SELECT hostname FROM clients WHERE hostname LIKE ?", (f"%{hostname}%",))
            matches = cursor.fetchall()
            
            if not matches:
                print(f"❌ No client found matching '{hostname}'")
                return
            elif len(matches) > 1:
                print(f"\n🔍 Multiple clients found matching '{hostname}':")
                for i, match in enumerate(matches, 1):
                    print(f"  {i}. {match['hostname']}")
                
                choice = input("\nSelect client (1-{0}) or Q to cancel: ".format(len(matches))).strip()
                if choice.upper() == 'Q':
                    return
                try:
                    idx = int(choice) - 1
                    hostname = matches[idx]['hostname']
                except (ValueError, IndexError):
                    print("❌ Invalid selection")
                    return
            else:
                hostname = matches[0]['hostname']
        
        # Display software for this client (paginated)
        page = 0
        while True:
            results, total, total_pages = self.get_client_software(hostname, page)
            
            print("\n" + "="*100)
            print(f"📦 SOFTWARE INSTALLED ON: {hostname}")
            print(f"    Page {page + 1} of {total_pages} | Total: {total} packages")
            print("="*100)
            print(f"\n{'Software Name':<50} {'Version':<20} {'Vendor':<30}")
            print("-"*100)
            
            for row in results:
                name = row['software_name'] or 'N/A'
                version = row['version'] or 'N/A'
                vendor = row['vendor'] or 'N/A'
                
                # Truncate long fields
                name = (name[:47] + '...') if len(name) > 50 else name
                version = (version[:17] + '...') if len(version) > 20 else version
                vendor = (vendor[:27] + '...') if len(vendor) > 30 else vendor
                
                print(f"{name:<50} {version:<20} {vendor:<30}")
            
            print("-"*100)
            
            if total_pages > 1:
                nav = input("\n[N]ext page, [P]revious page, [Q]uit: ").strip().upper()
                if nav == 'N' and page < total_pages - 1:
                    page += 1
                elif nav == 'P' and page > 0:
                    page -= 1
                elif nav == 'Q':
                    break
                else:
                    if nav == 'N':
                        print("⚠️  Already on last page")
                    elif nav == 'P':
                        print("⚠️  Already on first page")
                    input("Press Enter to continue...")
            else:
                break
    
    def search_software_interactive(self):
        """Interactive software search"""
        search_term = input("\nEnter software name or vendor to search: ").strip()
        
        if not search_term:
            print("❌ Search term required")
            return
        
        page = 0
        while True:
            results, total, total_pages = self.search_software(search_term, page)
            
            if total == 0:
                print(f"\n❌ No software found matching '{search_term}'")
                return
            
            print("\n" + "="*110)
            print(f"🔍 SEARCH RESULTS FOR: '{search_term}'")
            print(f"    Page {page + 1} of {total_pages} | Total: {total} matches")
            print("="*110)
            print(f"\n{'Hostname':<20} {'Software Name':<45} {'Version':<20} {'Vendor':<25}")
            print("-"*110)
            
            for row in results:
                hostname = row['hostname'] or 'N/A'
                name = row['software_name'] or 'N/A'
                version = row['version'] or 'N/A'
                vendor = row['vendor'] or 'N/A'
                
                # Truncate
                name = (name[:42] + '...') if len(name) > 45 else name
                version = (version[:17] + '...') if len(version) > 20 else version
                vendor = (vendor[:22] + '...') if len(vendor) > 25 else vendor
                
                print(f"{hostname:<20} {name:<45} {version:<20} {vendor:<25}")
            
            print("-"*110)
            
            if total_pages > 1:
                nav = input("\n[N]ext page, [P]revious page, [Q]uit: ").strip().upper()
                if nav == 'N' and page < total_pages - 1:
                    page += 1
                elif nav == 'P' and page > 0:
                    page -= 1
                elif nav == 'Q':
                    break
            else:
                break
    
    def find_software_distribution(self):
        """Find which clients have a specific software"""
        software = input("\nEnter exact software name: ").strip()
        
        if not software:
            print("❌ Software name required")
            return
        
        results = self.get_software_distribution(software)
        
        if not results:
            print(f"\n❌ '{software}' not found on any client")
            return
        
        print("\n" + "="*100)
        print(f"📊 SOFTWARE DISTRIBUTION: {software}")
        print(f"    Found on {len(results)} client(s)")
        print("="*100)
        print(f"\n{'Hostname':<20} {'Version':<20} {'Vendor':<30} {'Install Date'}")
        print("-"*100)
        
        for row in results:
            hostname = row['hostname'] or 'N/A'
            version = row['version'] or 'N/A'
            vendor = row['vendor'] or 'N/A'
            install_date = row['install_date'] or 'N/A'
            
            print(f"{hostname:<20} {version:<20} {vendor:<30} {install_date}")
        
        print("-"*100)
    
    def export_to_csv(self):
        """Export inventory to CSV"""
        filename = input("\nEnter filename (default: inventory_export.csv): ").strip()
        if not filename:
            filename = "inventory_export.csv"
        
        if not filename.endswith('.csv'):
            filename += '.csv'
        
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT 
                c.hostname,
                s.software_name,
                s.software_version as version,
                s.vendor,
                s.install_date,
                s.scan_timestamp as scanned_at
            FROM software_inventory s
            JOIN clients c ON s.client_id = c.client_id
            ORDER BY c.hostname, s.software_name
        """)
        
        import csv
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Hostname', 'Software', 'Version', 'Vendor', 'Install Date', 'Scanned At'])
            writer.writerows(cursor.fetchall())
        
        print(f"\n✅ Exported to {filename}")
        print(f"   Total records: {cursor.rowcount}")
    
    def close(self):
        """Close database connection"""
        self.conn.close()


def main():
    print("\n" + "="*70)
    print("📊 N2NHU INVENTORY DATABASE VIEWER")
    print("="*70)
    
    # Check if database exists in current directory
    if os.path.exists("network_management.db"):
        db_path = "network_management.db"
    else:
        db_path = input("\nEnter database path (or press Enter for 'network_management.db'): ").strip()
        if not db_path:
            db_path = "network_management.db"
    
    viewer = InventoryViewer(db_path)
    
    try:
        viewer.interactive_menu()
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted by user")
    finally:
        viewer.close()


if __name__ == "__main__":
    main()
