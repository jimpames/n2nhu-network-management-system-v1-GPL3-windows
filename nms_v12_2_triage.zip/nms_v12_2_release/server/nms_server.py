#!/usr/bin/env python3
"""
N2NHU NETWORK COMMAND SERVER - V3 ENHANCED
Universal Network & Endpoint Management Platform

V3 ENHANCED FEATURES:
- Complete Hardware Inventory (CPU, RAM, Disk)
- MSI Package Import & Deployment
- Windows User Account Management (Create/Delete)
- Software Uninstallation (System-wide or Per-Client)
- Credential Management (Domain/Local Admin)
- WMIC Software Inventory Integration
- Database Storage with Full Audit Trail


V4 ENHANCEMENTS (NEW - February 2026):
- Chunked File Transfer (64KB chunks, constant memory)
- SHA256 Integrity Validation (every transfer verified)
- Progress Tracking (real-time feedback with progress bars)
- Bandwidth Throttling (configurable QoS)
- Retry/Resume Foundation (chunk-level tracking)
- Enhanced Error Handling
- Memory Efficient (99% reduction for large files)
"""

import configparser
import socket
import threading
from virtual_dhcp_v12 import VirtualDHCPServer
from network_utils import list_network_adapters, get_adapter_network, suggest_ip_pool, validate_ip
import dhcp_menu_v12 as dhcp_menu
import time
from queue import Queue, Empty
import json
import sqlite3
import hashlib
import hmac
import secrets
import getpass
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple, Any
from pathlib import Path
from enum import Enum
from datetime import datetime, timedelta
import logging
import base64
import os
import uuid
import shutil
from cryptography.fernet import Fernet

# V12.2: Explicit sqlite3 datetime adapters (Python 3.12+ deprecated the defaults)
sqlite3.register_adapter(datetime, lambda dt: dt.isoformat(sep=' '))
sqlite3.register_converter("TIMESTAMP", lambda b: datetime.fromisoformat(b.decode()))

# V4 ENHANCED: File transfer module
from file_transfer import ChunkedFileSender, FileHasher, format_bytes




# ============================================================================
# NEWLINE-DELIMITED JSON FRAMING HELPERS (TCP-Safe)
# ============================================================================

MAX_LINE_BYTES = 4 * 1024 * 1024  # 4MB safety cap

def send_json_line(sock, obj):
    """Send JSON object with newline delimiter (TCP-safe)"""
    data = (json.dumps(obj, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")
    sock.sendall(data)

def recv_json_lines(sock, buffer):
    """Yield complete JSON objects from newline-delimited stream"""
    chunk = sock.recv(65536)
    if not chunk:
        raise ConnectionError("Socket closed by peer")
    buffer.extend(chunk)
    
    while True:
        nl = buffer.find(b"\n")
        if nl < 0:
            if len(buffer) > MAX_LINE_BYTES:
                raise ValueError("JSON line exceeds MAX_LINE_BYTES")
            return
        
        line = bytes(buffer[:nl])
        del buffer[:nl + 1]
        
        if not line.strip():
            continue
        
        if len(line) > MAX_LINE_BYTES:
            raise ValueError("Single JSON message too large")
        
        try:
            yield json.loads(line.decode("utf-8"))
        except json.JSONDecodeError as e:
            raise ValueError(f"Bad JSON line: {e}") from e




# ============================================================================
# V7: MESSAGE FILTERING HELPER (Prevents Queue Message Stealing)
# ============================================================================

def wait_for_message(
    client,
    predicate,
    timeout,
    on_ignored=None
):
    """
    V7: Wait for a message in client.message_queue that matches predicate.
    
    Solves: FIFO queue ≠ "the next message is the one I want"
    
    - Returns the first matching message, or None on timeout
    - Messages that don't match are forwarded to on_ignored (background processing)
    - This ensures heartbeats/inventory don't break deploy workflow
    
    Args:
        client: Client object with message_queue
        predicate: Function that returns True for desired message
        timeout: Maximum seconds to wait
        on_ignored: Callback for non-matching messages (optional)
    
    Returns:
        Matching message dict, or None if timeout
    """
    import time
    from queue import Empty
    
    deadline = time.monotonic() + timeout
    
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return None
        
        try:
            msg = client.message_queue.get(timeout=remaining)
        except Empty:
            return None
        
        if not isinstance(msg, dict):
            # Ignore garbage; don't crash deploy
            continue
        
        # Check if this is the message we're waiting for
        if predicate(msg):
            return msg
        
        # Not the one we want - hand to background processing
        if on_ignored is not None:
            try:
                on_ignored(msg)
            except Exception:
                # Never let background processing break wait loop
                pass




# ============================================================================
# V8: LENGTH-PREFIXED JSON HELPERS (Transfer Channel Handshake)
# ============================================================================

def send_lp_json(sock, obj):
    """Send length-prefixed JSON (for transfer channel)"""
    import struct
    data = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    sock.sendall(struct.pack("!I", len(data)) + data)

def _recv_exact(sock, n):
    """Receive exactly n bytes from socket (handles TCP short reads)"""
    data = b""
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk:
            raise ConnectionError("Connection closed during recv_exact")
        data += chunk
    return data

def recv_lp_json(sock):
    """Receive length-prefixed JSON (for transfer channel) - V9: Fixed short-read bug"""
    import struct
    # V9: Use _recv_exact to handle TCP short reads properly
    length_bytes = _recv_exact(sock, 4)
    (n,) = struct.unpack("!I", length_bytes)
    
    # V9: Use _recv_exact for payload too
    data = _recv_exact(sock, n)
    return json.loads(data.decode("utf-8"))


def load_config():
    """Load configuration from INI file or use defaults"""
    config = {
        'server_host': '0.0.0.0',
        'server_port': 2222,
        'db_path': 'network_management.db',
        'auto_backup': True,
        'backup_dir': 'backups',
        'skip_credential_prompt': False,
        'packages_dir': 'deployables',
        'max_package_size_mb': 500,
        'require_tls': False,
        'tls_cert_file': '',
        'tls_key_file': '',
        'log_level': 'INFO',
        'log_to_file': False,
        'log_file': 'nms_server.log',
        'max_clients': 1000,
        'client_timeout': 300,
        'db_pool_size': 10,
        'transfer_port': 2223,  # Separate port for chunked file transfers
    }
    
    config_file = 'nms_server_config.ini'
    
    if os.path.exists(config_file):
        try:
            parser = configparser.ConfigParser()
            parser.read(config_file)
            
            # Server settings
            if parser.has_section('server'):
                config['server_host'] = parser.get('server', 'host', fallback=config['server_host'])
                config['server_port'] = parser.getint('server', 'port', fallback=config['server_port'])
                config['transfer_port'] = parser.getint('server', 'transfer_port', fallback=config['transfer_port'])
            
            # Database settings
            if parser.has_section('database'):
                config['db_path'] = parser.get('database', 'path', fallback=config['db_path'])
                config['auto_backup'] = parser.getboolean('database', 'auto_backup', fallback=config['auto_backup'])
                config['backup_dir'] = parser.get('database', 'backup_dir', fallback=config['backup_dir'])
            
            # Credentials settings
            if parser.has_section('credentials'):
                config['skip_credential_prompt'] = parser.getboolean('credentials', 'skip_credential_prompt', fallback=config['skip_credential_prompt'])
            
            # Deployables settings
            if parser.has_section('deployables'):
                config['packages_dir'] = parser.get('deployables', 'packages_dir', fallback=config['packages_dir'])
                config['max_package_size_mb'] = parser.getint('deployables', 'max_package_size_mb', fallback=config['max_package_size_mb'])
            
            # Security settings
            if parser.has_section('security'):
                config['require_tls'] = parser.getboolean('security', 'require_tls', fallback=config['require_tls'])
                config['tls_cert_file'] = parser.get('security', 'tls_cert_file', fallback=config['tls_cert_file'])
                config['tls_key_file'] = parser.get('security', 'tls_key_file', fallback=config['tls_key_file'])
            
            # Logging settings
            if parser.has_section('logging'):
                config['log_level'] = parser.get('logging', 'log_level', fallback=config['log_level'])
                config['log_to_file'] = parser.getboolean('logging', 'log_to_file', fallback=config['log_to_file'])
                config['log_file'] = parser.get('logging', 'log_file', fallback=config['log_file'])
            
            # Performance settings
            if parser.has_section('performance'):
                config['max_clients'] = parser.getint('performance', 'max_clients', fallback=config['max_clients'])
                config['client_timeout'] = parser.getint('performance', 'client_timeout', fallback=config['client_timeout'])
                config['db_pool_size'] = parser.getint('performance', 'db_pool_size', fallback=config['db_pool_size'])
            
            print(f"✅ Loaded configuration from {config_file}")
            
        except Exception as e:
            print(f"⚠️  Error reading {config_file}: {e}")
            print("Using default configuration")
    else:
        print(f"â„¹ï¸  No {config_file} found, using defaults")
    
    return config


# Load configuration
CONFIG = load_config()

# Configure logging
log_level = getattr(logging, CONFIG['log_level'].upper(), logging.INFO)
log_handlers = []

if CONFIG['log_to_file']:
    log_handlers.append(logging.FileHandler(CONFIG['log_file']))

log_handlers.append(logging.StreamHandler())

logging.basicConfig(
    level=log_level,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=log_handlers
)
logger = logging.getLogger(__name__)


class OperationType(Enum):
    """Types of network management operations"""
    INVENTORY_SCAN = "inventory_scan"
    SOFTWARE_INSTALL = "software_install"
    SOFTWARE_UNINSTALL = "software_uninstall"
    PACKAGE_DEPLOY = "package_deploy"
    USER_ACCOUNT_CREATE = "user_account_create"
    USER_ACCOUNT_DELETE = "user_account_delete"
    CREDENTIAL_DEPLOY = "credential_deploy"
    CREDENTIAL_TEST = "credential_test"
    REMOTE_COMMAND = "remote_command"
    DISCOVERY_SCAN = "discovery_scan"
    COMPLIANCE_CHECK = "compliance_check"
    HEARTBEAT = "heartbeat"


class ClientStatus(Enum):
    """Client connection status"""
    ONLINE = "online"
    OFFLINE = "offline"
    UNKNOWN = "unknown"
    MAINTENANCE = "maintenance"


@dataclass
class Client:
    """Network client/endpoint"""
    client_id: str
    hostname: str
    ip_address: str
    mac_address: str
    os_type: str
    os_version: str
    domain: Optional[str] = None
    department: Optional[str] = None
    location: Optional[str] = None
    groups: Set[str] = field(default_factory=set)
    status: ClientStatus = ClientStatus.UNKNOWN
    last_seen: Optional[datetime] = None
    agent_version: Optional[str] = None
    credentials_configured: bool = False
    credential_type: Optional[str] = None  # 'domain' or 'local'
    last_inventory_scan: Optional[datetime] = None
    software_count: int = 0
    properties: Dict[str, str] = field(default_factory=dict)
    connection: Optional[Any] = None
    
    def is_online(self) -> bool:
        """Check if client is currently online"""
        if not self.last_seen:
            return False
        return (datetime.now() - self.last_seen) < timedelta(minutes=5)
    
    def update_heartbeat(self):
        """Update last seen timestamp"""
        self.last_seen = datetime.now()
        self.status = ClientStatus.ONLINE


class CredentialManager:
    """
    Manages credentials for domain admin and local admin accounts
    Encrypts credentials for secure storage and transmission
    """
    
    def __init__(self):
        self.encryption_key = Fernet.generate_key()
        self.cipher = Fernet(self.encryption_key)
        self.domain_credentials = None
        self.local_credentials = None
    
    def collect_credentials_interactive(self):
        """
        Collect credentials interactively at server startup
        THE GOLDMINE STARTS HERE!
        """
        print("\n" + "="*70)
        print("CREDENTIAL COLLECTION FOR REMOTE MANAGEMENT")
        print("="*70)
        print("\nN2NHU needs credentials for:")
        print("  • WMIC software inventory collection")
        print("  • Windows user account creation/deletion")
        print("  • Software installation/removal")
        print("\nYou can provide DOMAIN credentials (for domain-joined machines)")
        print("and/or LOCAL credentials (for non-domain machines).")
        print("")
        
        # Domain Admin Credentials
        print("\n--- DOMAIN ADMIN CREDENTIALS ---")
        use_domain = input("Do you want to configure Domain Admin credentials? (y/n): ").strip().lower()
        
        if use_domain == 'y':
            domain = input("Domain name (e.g., CONTOSO): ").strip()
            username = input("Domain admin username: ").strip()
            password = getpass.getpass("Domain admin password: ")
            
            self.domain_credentials = {
                'type': 'domain',
                'domain': domain,
                'username': username,
                'password': password,
                'configured_at': datetime.now().isoformat()
            }
            
            print(f"✅ Domain credentials configured: {domain}\\{username}")
        else:
            print("⏭️  Skipping domain credentials")
        
        # Local Admin Credentials
        print("\n--- LOCAL ADMIN CREDENTIALS ---")
        use_local = input("Do you want to configure Local Admin credentials? (y/n): ").strip().lower()
        
        if use_local == 'y':
            username = input("Local admin username (e.g., Administrator): ").strip()
            password = getpass.getpass("Local admin password: ")
            
            self.local_credentials = {
                'type': 'local',
                'domain': None,
                'username': username,
                'password': password,
                'configured_at': datetime.now().isoformat()
            }
            
            print(f"✅ Local credentials configured: {username}")
        else:
            print("⏭️  Skipping local credentials")
        
        print("\n" + "="*70)
        
        if self.domain_credentials or self.local_credentials:
            print("✅ Credential collection complete!")
            print("   Credentials will be pushed to all connected clients.")
        else:
            print("⚠️  No credentials configured. Remote management features limited.")
        
        print("="*70 + "\n")
    
    def encrypt_credentials(self, credentials: Dict) -> str:
        """Encrypt credentials for transmission"""
        json_str = json.dumps(credentials)
        encrypted = self.cipher.encrypt(json_str.encode())
        return base64.b64encode(encrypted).decode()
    
    def get_credentials_for_client(self, client: Client) -> Optional[Dict]:
        """
        Get appropriate credentials for a client
        Domain-joined = domain creds, otherwise local creds
        """
        # Check if client is domain-joined
        if client.domain and self.domain_credentials:
            return self.domain_credentials
        elif self.local_credentials:
            return self.local_credentials
        else:
            return None


class NetworkManagementServer:
    """
    N2NHU Network Command Server - V3 ENHANCED
    Manages network endpoints using transformation-based operations
    """
    
    def __init__(self, config_path: str = "config", db_path: str = None):
        self.config_path = Path(config_path)
        self.db_path = db_path or CONFIG['db_path']
        
        # Core components
        self.clients: Dict[str, Client] = {}
        self.credential_manager = CredentialManager()
        
        # Statistics
        self.operations_processed = 0
        self.operations_succeeded = 0
        self.operations_failed = 0
        self.transformations_applied = 0
        
        # Server state
        self.running = False
        self.server_socket = None
        self.server_thread = None

        # V8: Transfer channel components
        self.transfer_port = CONFIG.get("transfer_port", 2223)
        self.transfer_socket = None
        self.transfer_thread = None
        self.pending_transfers = {}  # transfer_id -> {client_id, sock}
        self.pending_transfers_lock = threading.Lock()
        
        # Auto-backup database if configured
        if CONFIG['auto_backup']:
            self.backup_database()
        
        # Initialize database
        self.init_database()
        
        # Collect credentials at startup (unless skipped in config)
        if not CONFIG['skip_credential_prompt']:
            self.credential_manager.collect_credentials_interactive()
        else:
            logger.warning("⚠️  Credential prompt skipped (configured in INI)")
            logger.warning("   Inventory and account management will not work without credentials!")
            
        # V10: Initialize Virtual DHCP Server for VPN
        try:
            self.dhcp_server = VirtualDHCPServer(db_path=self.db_path)
            logger.info("📡 Virtual DHCP server initialized")
        except Exception as e:
            logger.warning(f"DHCP server initialization failed: {e}")
            self.dhcp_server = None


    def backup_database(self):
        """Backup database file if it exists"""
        if not os.path.exists(self.db_path):
            return
        
        try:
            backup_dir = CONFIG['backup_dir']
            if not os.path.exists(backup_dir):
                os.makedirs(backup_dir)
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_file = os.path.join(backup_dir, f"network_management_{timestamp}.db")
            
            shutil.copy2(self.db_path, backup_file)
            logger.info(f"✅ Database backed up to: {backup_file}")
            
            # Keep only last 10 backups
            backups = sorted([f for f in os.listdir(backup_dir) if f.endswith('.db')])
            if len(backups) > 10:
                for old_backup in backups[:-10]:
                    os.remove(os.path.join(backup_dir, old_backup))
                    logger.info(f"🗑️  Removed old backup: {old_backup}")
                    
        except Exception as e:
            logger.error(f"❌ Database backup failed: {e}")
    
    def init_database(self):
        """Initialize SQLite database with schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Clients table (V3: Added hardware columns!)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clients (
                client_id TEXT PRIMARY KEY,
                hostname TEXT,
                ip_address TEXT,
                mac_address TEXT,
                os_type TEXT,
                os_version TEXT,
                domain TEXT,
                status TEXT,
                last_seen TIMESTAMP,
                credentials_configured INTEGER,
                credential_type TEXT,
                last_inventory_scan TIMESTAMP,
                software_count INTEGER DEFAULT 0,
                cpu_info TEXT,
                ram_info TEXT,
                disk_info TEXT
            )
        """)
        
        # Software inventory table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS software_inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT,
                software_name TEXT,
                software_version TEXT,
                vendor TEXT,
                install_date TEXT,
                scan_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (client_id) REFERENCES clients(client_id)
            )
        """)
        
        # Create index for faster queries
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_client_software 
            ON software_inventory(client_id, software_name)
        """)
        
        # Operations log
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS operations_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                operation_type TEXT,
                client_id TEXT,
                status TEXT,
                exit_code INTEGER,
                error_message TEXT,
                duration_seconds REAL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (client_id) REFERENCES clients(client_id)
            )
        """)
        
        # Software Packages Repository (ENHANCED)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS software_packages (
                package_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                version TEXT,
                install_type TEXT,
                size_mb REAL,
                import_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                file_path TEXT,
                description TEXT
            )
        """)
        
        # Package Deployments Tracking (ENHANCED)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS package_deployments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                package_id TEXT,
                client_id TEXT,
                status TEXT,
                deploy_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completion_timestamp TIMESTAMP,
                exit_code INTEGER,
                error_message TEXT,
                FOREIGN KEY (package_id) REFERENCES software_packages(package_id),
                FOREIGN KEY (client_id) REFERENCES clients(client_id)
            )
        """)
        
        # User Account Operations (ENHANCED)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_account_operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT,
                operation TEXT,
                username TEXT,
                account_type TEXT,
                status TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                error_message TEXT,
                FOREIGN KEY (client_id) REFERENCES clients(client_id)
            )
        """)
        
        conn.commit()
        conn.close()
        
        logger.info("✅ Database initialized with ENHANCED schema")
    
    def start_server(self, host: str = None, port: int = None):
        """Start the network management server"""
        # Use config values if not explicitly provided
        host = host or CONFIG['server_host']
        port = port or CONFIG['server_port']
        
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((host, port))
        self.server_socket.listen(CONFIG['max_clients'])
        self.running = True
        
        logger.info(f"🚀 N2NHU Network Command Server ENHANCED started on {host}:{port}")
        logger.info(f"   Max concurrent clients: {CONFIG['max_clients']}")
        
        # V8: Start transfer socket listener (separate port for file transfers)
        self.transfer_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.transfer_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.transfer_socket.bind((host, self.transfer_port))
        self.transfer_socket.listen(CONFIG.get('max_clients', 1000))
        logger.info(f"📦 Transfer channel listening on {host}:{self.transfer_port}")
        
        # Start accept thread
        self.server_thread = threading.Thread(target=self._accept_clients, daemon=True)
        self.server_thread.start()
        
        # V8: Start transfer channel accept thread
        self.transfer_thread = threading.Thread(target=self._accept_transfer_clients, daemon=True)
        self.transfer_thread.start()
    
    def _accept_clients(self):
        """Accept incoming client connections"""
        while self.running:
            try:
                client_sock, client_addr = self.server_socket.accept()
                logger.info(f"📞 New connection from {client_addr}")
                
                # Handle each client in separate thread
                client_thread = threading.Thread(
                    target=self._handle_client,
                    args=(client_sock, client_addr),
                    daemon=True
                )
                client_thread.start()
                
            except Exception as e:
                if self.running:
                    logger.error(f"Error accepting client: {e}")
    
    def _handle_client(self, client_sock, client_addr):
        """Handle individual client connection"""
        client_id = None
        client = None  # V12.2: declare so finally can safely check identity
        
        try:
            # Receive handshake (client registration) - TCP-safe framed receive
            buf = bytearray()
            try:
                for handshake in recv_json_lines(client_sock, buf):
                    break  # Get first message
            except (ConnectionError, ValueError):
                return
            client_id = handshake.get('client_id')
            
            # Create or update client record
            client = Client(
                client_id=client_id,
                hostname=handshake.get('hostname', 'UNKNOWN'),
                ip_address=handshake.get('ip_address', client_addr[0]),
                mac_address=handshake.get('mac_address', '00:00:00:00:00:00'),
                os_type=handshake.get('os_type', 'unknown'),
                os_version=handshake.get('os_version', ''),
                domain=handshake.get('domain'),
                agent_version=handshake.get('agent_version'),
                connection=client_sock
            )
            
            # V6: Initialize message queue for this client
            client.message_queue = Queue()
            
            client.update_heartbeat()

            # V12.2: If a client with this ID is already connected, tear
            # down the old session cleanly before installing the new one.
            # Prevents two threads racing on the same Client object when
            # a client reconnects after a crash/network blip.
            old = self.clients.get(client_id)
            if old is not None and old.connection is not None and old.connection is not client_sock:
                try:
                    logger.info(f"🔄 Evicting stale session for {client_id} (reconnect)")
                    old.status = ClientStatus.OFFLINE
                    try:
                        old.connection.shutdown(socket.SHUT_RDWR)
                    except (OSError, AttributeError):
                        pass
                    try:
                        old.connection.close()
                    except (OSError, AttributeError):
                        pass
                    old.connection = None
                except Exception as e:
                    logger.warning(f"Error evicting old session for {client_id}: {e}")

            self.clients[client_id] = client
            
            # Save to database
            self._save_client_to_db(client)
            
            logger.info(f"✅ Client registered: {client.hostname} ({client_id})")
            
            # Send acknowledgment
            ack = {
                'status': 'connected',
                'server_time': datetime.now().isoformat()
            }
            send_json_line(client_sock, ack)
            
            # Push credentials if available
            self._push_credentials_to_client(client)
            
            # Listen for client messages (heartbeats, results, etc)
            self._client_message_loop(client, client_sock)
            
        except Exception as e:
            logger.error(f"Error handling client: {e}")
        finally:
            # V12.2: Only clear state if the clients dict still points
            # at OUR Client record. If a newer handshake replaced us
            # (reconnect), the newer thread owns the record now — we
            # must not clobber its connection.
            if client_id and client is not None:
                current = self.clients.get(client_id)
                if current is client:
                    current.status = ClientStatus.OFFLINE
                    current.connection = None
                    logger.info(f"Client disconnected: {client_id}")
    
    def _client_message_loop(self, client: Client, client_sock):
        """
        V6: Single reader thread - reads from socket and pushes to queue
        This is the ONLY place that calls recv() on this socket
        """
        buffer = bytearray()
        
        while self.running and client.is_online():
            try:
                # SINGLE READER: Only this thread calls recv()
                for message in recv_json_lines(client_sock, buffer):
                    # Push to queue for deploy workflow to consume
                    client.message_queue.put(message)
                    
                    # Also process background messages immediately
                    msg_type = message.get('type')
                    if msg_type in ['heartbeat', 'inventory_report', 'operation_result']:
                        self._process_client_message(client, message)
                
            except (ConnectionError, OSError):
                logger.info(f"Client {client.client_id} disconnected")
                break
            except Exception as e:
                logger.error(f"Error in message loop for {client.client_id}: {e}")
                break


    def _accept_transfer_clients(self):
        """
        V8: Dedicated thread for accepting transfer channel connections.
        Runs on separate port (2223 by default) for file transfers only.
        """
        logger.info(f"📦 Transfer listener started on port {self.transfer_port}")
        
        while self.running:
            try:
                sock, addr = self.transfer_socket.accept()
                sock.settimeout(30)
                
                # Expect length-prefixed JSON hello
                try:
                    hello = recv_lp_json(sock)
                except Exception as e:
                    logger.warning(f"Bad transfer hello from {addr}: {e}")
                    sock.close()
                    continue
                
                if hello.get('type') != 'transfer_hello':
                    logger.warning(f"Wrong message type on transfer channel: {hello.get('type')}")
                    sock.close()
                    continue
                
                transfer_id = hello.get('transfer_id')
                client_id = hello.get('client_id')
                transfer_token = hello.get('transfer_token')  # V9: Get token from client
                
                # V9: Match to pending transfer AND verify security token
                with self.pending_transfers_lock:
                    entry = self.pending_transfers.get(transfer_id)
                    if not entry or entry.get('client_id') != client_id:
                        logger.warning(f"Unknown transfer: {transfer_id} from {client_id}")
                        sock.close()
                        continue
                    # V9: Verify security token
                    if entry.get('token') != transfer_token:
                        logger.warning(f"Invalid transfer token for {transfer_id}")
                        sock.close()
                        continue
                    entry['sock'] = sock  # Attach socket
                
                logger.info(f"✅ Transfer channel connected: {client_id} transfer={transfer_id[:12]}...")
                
            except Exception as e:
                if self.running:
                    logger.error(f"Transfer accept error: {e}")


    
    def handle_vpn_connect_request(self, client, message):
        """V10: Handle VPN connection request from client"""
        try:
            if not self.dhcp_server:
                logger.warning("DHCP server not initialized")
                return
            
            if not self.dhcp_server.config.get('enabled'):
                logger.warning("DHCP server is disabled")
                return
            
            client_id = message.get('client_id')
            hostname = message.get('hostname', 'Unknown')
            mac_address = message.get('mac_address', 'Unknown')
            wan_ip = message.get('wan_ip', 'Unknown')
            
            logger.info(f"📡 VPN connection request from {hostname} ({client_id})")
            
            # V11: Allocate + persist lease atomically (single call!)
            try:
                vpn_ip = self.dhcp_server.register_client(client_id, hostname, mac_address, wan_ip)
                
                # Generate configuration
                config = {
                    'vpn_ip': vpn_ip,
                    'subnet_mask': self.dhcp_server.config.get('subnet_mask', '255.255.255.0'),
                    'gateway': self.dhcp_server.config.get('gateway'),
                    'dns_servers': self.dhcp_server.config.get('dns_servers', []),
                    'network': self.dhcp_server.config.get('network')
                }
                
                # Send VPN configuration to client
                send_json_line(client.connection, {
                    'type': 'vpn_config',
                    'status': 'ok',
                    'config': config
                })
                
                logger.info(f"✅ Assigned {vpn_ip} to {hostname}")
                
            except Exception as e:
                logger.error(f"VPN IP allocation failed: {e}")
                send_json_line(client.connection, {
                    'type': 'vpn_config',
                    'status': 'failed',
                    'error': str(e)
                })
                
        except Exception as e:
            logger.error(f"Error handling VPN request: {e}")

    def _process_client_message(self, client: Client, message: dict):
        """Process messages received from client"""
        msg_type = message.get('type')
        
        if msg_type == 'heartbeat':
            client.update_heartbeat()
        
        elif msg_type == 'vpn_connect_request':
            self.handle_vpn_connect_request(client, message)

        elif msg_type == 'inventory_report':
            self._handle_inventory_report(client, message)
        
        elif msg_type == 'operation_result':
            self._log_operation_result(client.client_id, message.get('result', {}))
    
    def _handle_inventory_report(self, client: Client, message: dict):
        """Process inventory report from client"""
        inventory = message.get('inventory', {})
        
        # Extract hardware info (V3 ENHANCEMENT)
        hardware = inventory.get('hardware', {})
        
        # Update client record
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE clients
            SET last_inventory_scan = ?,
                cpu_info = ?,
                ram_info = ?,
                disk_info = ?
            WHERE client_id = ?
        """, (
            datetime.now(),
            hardware.get('cpu'),
            hardware.get('ram'),
            hardware.get('disk'),
            client.client_id
        ))
        
        # Clear old inventory for this client
        cursor.execute("DELETE FROM software_inventory WHERE client_id = ?", (client.client_id,))
        
        # Insert new software inventory
        software_list = inventory.get('software', [])
        for sw in software_list:
            cursor.execute("""
                INSERT INTO software_inventory 
                (client_id, software_name, software_version, vendor, install_date)
                VALUES (?, ?, ?, ?, ?)
            """, (
                client.client_id,
                sw.get('name'),
                sw.get('version'),
                sw.get('vendor'),
                sw.get('install_date')
            ))
        
        # Update software count
        cursor.execute("""
            UPDATE clients
            SET software_count = ?
            WHERE client_id = ?
        """, (len(software_list), client.client_id))
        
        conn.commit()
        conn.close()
        
        logger.info(f"📊 Inventory updated for {client.hostname}: {len(software_list)} software packages")

        # Send acknowledgment to client
        try:
            ack = {'type': 'inventory_ack', 'status': 'ok'}
            send_json_line(client.connection, ack)
        except:
            pass
            
    def _save_client_to_db(self, client: Client):
        """Save or update client in database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO clients
            (client_id, hostname, ip_address, mac_address, os_type, os_version, 
             domain, status, last_seen, credentials_configured)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            client.client_id,
            client.hostname,
            client.ip_address,
            client.mac_address,
            client.os_type,
            client.os_version,
            client.domain,
            client.status.value,
            client.last_seen,
            client.credentials_configured
        ))
        
        conn.commit()
        conn.close()
    
    def _push_credentials_to_client(self, client: Client):
        """Push appropriate credentials to client for remote operations"""
        credentials = self.credential_manager.get_credentials_for_client(client)
        
        if not credentials:
            logger.warning(f"No credentials available for {client.hostname}")
            return
        
        try:
            # Encrypt credentials
            encrypted_creds = self.credential_manager.encrypt_credentials(credentials)
            encryption_key = base64.b64encode(self.credential_manager.encryption_key).decode()
            
            # Create push command
            push_cmd = {
                'type': 'credential_deploy',
                'credentials_encrypted': encrypted_creds,
                'encryption_key': encryption_key
            }
            
            # Send to client
            send_json_line(client.connection, push_cmd)
            
            # Update database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE clients
                SET credentials_configured = 1,
                    credential_type = ?
                WHERE client_id = ?
            """, (credentials['type'], client.client_id))
            conn.commit()
            conn.close()
            
            client.credentials_configured = True
            client.credential_type = credentials['type']
            
            logger.info(f"🔑 Pushed {credentials['type']} credentials to {client.hostname}")
            
        except Exception as e:
            logger.error(f"Failed to push credentials to {client.hostname}: {e}")
    
    def _log_operation_result(self, client_id: str, result: dict):
        """Log operation result to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO operations_log
            (operation_type, client_id, status, exit_code, error_message, duration_seconds)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            result.get('operation_type'),
            client_id,
            result.get('status'),
            result.get('exit_code'),
            result.get('error_message'),
            result.get('duration_seconds')
        ))
        
        conn.commit()
        conn.close()
        
        self.operations_processed += 1
        if result.get('status') == 'success':
            self.operations_succeeded += 1
        else:
            self.operations_failed += 1
    
    def trigger_inventory_refresh_all(self):
        """Trigger software inventory scan on all online clients"""
        print("\n" + "="*70)
        print("🔄 TRIGGERING INVENTORY REFRESH ON ALL CLIENTS")
        print("="*70)
        
        online_clients = [c for c in self.clients.values() if c.is_online()]
        
        if not online_clients:
            print("❌ No online clients available")
            return
        
        print(f"\n📡 Sending inventory scan command to {len(online_clients)} clients...")
        
        for client in online_clients:
            try:
                cmd = {
                    'type': 'inventory_scan',
                    'scan_software': True
                }
                send_json_line(client.connection, cmd)
                print(f"  ✅ Sent to {client.hostname}")
            except Exception as e:
                print(f"  ❌ Failed for {client.hostname}: {e}")
        
        print(f"\n✅ Refresh triggered! Inventory data will update as clients respond.")
        print("="*70)
    
    def get_statistics(self) -> dict:
        """Get current server statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM clients")
        total_clients = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM clients WHERE status='online'")
        online_clients = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM clients WHERE credentials_configured=1")
        clients_with_creds = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM clients WHERE last_inventory_scan IS NOT NULL")
        clients_with_inventory = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_clients': total_clients,
            'online_clients': online_clients,
            'offline_clients': total_clients - online_clients,
            'clients_with_credentials': clients_with_creds,
            'clients_with_inventory': clients_with_inventory,
            'operations_processed': self.operations_processed,
            'operations_succeeded': self.operations_succeeded,
            'operations_failed': self.operations_failed
        }
    
    def view_inventory_summary(self):
        """View inventory summary across all clients"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        print("\n" + "="*70)
        print("📊 INVENTORY SUMMARY")
        print("="*70)
        
        # Get client inventory status
        cursor.execute("""
            SELECT c.hostname, c.last_inventory_scan, c.software_count, c.credential_type
            FROM clients c
            ORDER BY c.hostname
        """)
        
        clients = cursor.fetchall()
        
        if not clients:
            print("No inventory data available yet.")
        else:
            print(f"\n{'Hostname':<20} {'Last Scan':<20} {'Software':<10} {'Cred Type':<12}")
            print("-"*70)
            
            for hostname, last_scan, sw_count, cred_type in clients:
                scan_str = last_scan[:16] if last_scan else 'Never'
                cred_str = cred_type or 'None'
                print(f"{hostname:<20} {scan_str:<20} {sw_count:<10} {cred_str:<12}")
        
        # Total software packages
        cursor.execute("SELECT COUNT(*) FROM software_inventory")
        total_sw = cursor.fetchone()[0]
        
        print("-"*70)
        print(f"Total Software Records: {total_sw}")
        print("="*70)
        
        conn.close()
    
    #
    # ================ ENHANCED FEATURES ================
    #
    
    # FEATURE 1: MSI PACKAGE MANAGEMENT
    
    def import_msi_package(self):
        """Import MSI package into deployables repository"""
        print("\n" + "="*70)
        print("📦 IMPORT MSI PACKAGE")
        print("="*70)
        
        file_path = input("Enter full path to MSI file: ").strip().strip('"')
        
        if not os.path.exists(file_path):
            print("❌ File not found!")
            return
        
        if not file_path.lower().endswith('.msi'):
            print("⚠️  Warning: File does not have .msi extension")
            response = input("Continue anyway? (y/n): ")
            if response.lower() != 'y':
                return
        
        try:
            filename = os.path.basename(file_path)
            file_size = os.path.getsize(file_path)
            
            # Check max size
            max_size_mb = CONFIG['max_package_size_mb']
            if file_size > max_size_mb * 1024 * 1024:
                print(f"❌ Package exceeds maximum size ({max_size_mb}MB)")
                return
            
            # Create deployables directory (use config)
            deploy_dir = Path(CONFIG['packages_dir'])
            deploy_dir.mkdir(exist_ok=True)
            
            # Copy file to deployables
            target_path = deploy_dir / filename
            print(f"🔄 Importing {filename} ({round(file_size/1024/1024, 2)} MB)...")
            
            with open(file_path, 'rb') as src, open(target_path, 'wb') as dst:
                dst.write(src.read())
            
            # Get optional metadata
            version = input("Version (optional, press Enter to skip): ").strip() or "1.0"
            description = input("Description (optional): ").strip() or ""
            
            # Register in Database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if exists
            cursor.execute("SELECT * FROM software_packages WHERE name=?", (filename,))
            if cursor.fetchone():
                print("⚠️  Package already exists, updating...")
                cursor.execute("""UPDATE software_packages 
                                SET size_mb=?, import_date=?, version=?, description=?, file_path=?
                                WHERE name=?""",
                            (file_size/1024/1024, datetime.now(), version, description, 
                             str(target_path), filename))
            else:
                package_id = f"pkg_{int(time.time())}"
                cursor.execute("""
                    INSERT INTO software_packages 
                    (package_id, name, version, install_type, size_mb, import_date, file_path, description)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (package_id, filename, version, "msi", file_size/1024/1024, 
                      datetime.now(), str(target_path), description))
            
            conn.commit()
            conn.close()
            
            print(f"✅ Successfully imported: {filename}")
            print(f"   Stored in: {target_path}")
            print(f"   Size: {round(file_size/1024/1024, 2)} MB")
            
        except Exception as e:
            print(f"❌ Import failed: {e}")
            import traceback
            traceback.print_exc()
    
    def view_deployables(self):
        """View all imported packages"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT name, version, size_mb, import_date, description
            FROM software_packages
            ORDER BY import_date DESC
        """)
        
        packages = cursor.fetchall()
        
        print("\n" + "="*80)
        print("📦 AVAILABLE DEPLOYABLES")
        print("="*80)
        
        if not packages:
            print("No packages imported yet. Use 'Import MSI Package' to add one.")
        else:
            print(f"\n{'Package Name':<30} {'Version':<10} {'Size (MB)':<12} {'Imported':<20}")
            print("-"*80)
            
            for name, version, size_mb, import_date, desc in packages:
                import_str = import_date[:16] if import_date else 'Unknown'
                print(f"{name:<30} {version:<10} {size_mb:<12.2f} {import_str:<20}")
                if desc:
                    print(f"  └─ {desc}")
        
        print("="*80)
        conn.close()
    
    def deploy_package_to_client(self, client_id, package_name):
        """Deploy MSI package to specific client"""
        client = self.clients.get(client_id)
        
        if not client:
            print(f"❌ Client {client_id} not found.")
            return
        
        if not client.is_online():
            print(f"❌ Client {client.hostname} is OFFLINE.")
            return
        
        if not client.connection:
            print(f"❌ Client {client.hostname} has no active connection.")
            return
        
        file_path = Path(CONFIG['packages_dir']) / package_name
        
        if not file_path.exists():
            print(f"❌ Package file not found: {package_name}")
            return
        
        try:
            print(f"🚀 Reading {package_name}...")
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            file_size_mb = len(file_data) / 1024 / 1024
            print(f"📦 Package size: {round(file_size_mb, 2)} MB")
            
            # Base64 encode for transport
            print("🔐 Encoding package for transport...")
            encoded_data = base64.b64encode(file_data).decode('utf-8')
            
            # Construct deployment command
            payload = {
                'type': 'stage_and_deploy',
                'filename': package_name,
                'file_data': encoded_data,
                'arguments': '/quiet /norestart'
            }
            
            print(f"📤 Pushing payload to {client.hostname}...")
            print(f"   Target: {client.ip_address}")
            print(f"   Payload size: {round(len(json.dumps(payload))/1024/1024, 2)} MB")
            
            # Send via established connection
            send_json_line(client.connection, payload)
            
            # Log deployment attempt
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO package_deployments (package_id, client_id, status)
                VALUES ((SELECT package_id FROM software_packages WHERE name=?), ?, 'in_progress')
            """, (package_name, client_id))
            conn.commit()
            conn.close()
            
            print("✅ Payload sent! Client is staging and deploying...")
            print("   (Check client console for status)")
            
        except Exception as e:
            print(f"❌ Deployment failed: {e}")
            import traceback
            traceback.print_exc()
    
    def deploy_software_interactive(self):
        """
        ENHANCED V4: Deploy package using chunked file transfer
        with SHA256 verification and progress tracking
        """
        print("\n" + "="*70)
        print("📦 SOFTWARE DEPLOYMENT - ENHANCED V4")
        print("="*70)
        
        # Get list of available packages
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT package_id, name, version, size_mb, description 
            FROM software_packages 
            ORDER BY import_date DESC
        """)
        packages = cursor.fetchall()
        
        if not packages:
            print("\n⚠️  No packages available. Import a package first (Option 5).")
            conn.close()
            return
        
        # Display packages
        print("\n📦 AVAILABLE PACKAGES:")
        for idx, (pkg_id, name, version, size_mb, desc) in enumerate(packages, 1):
            print(f"  [{idx}] {name} (v{version or 'Unknown'})")
            print(f"      Size: {size_mb:.2f} MB")
            if desc:
                print(f"      {desc}")
            print()
        
        # Select package
        try:
            pkg_choice = int(input("Select Package # to deploy (0 to cancel): "))
            if pkg_choice == 0:
                conn.close()
                return
            if pkg_choice < 1 or pkg_choice > len(packages):
                print("Invalid package selection")
                conn.close()
                return
        except ValueError:
            print("Invalid input")
            conn.close()
            return
        
        selected_package = packages[pkg_choice - 1]
        pkg_id, pkg_name, pkg_version, pkg_size_mb, pkg_desc = selected_package
        
        # Get package file path
        cursor.execute("SELECT file_path FROM software_packages WHERE package_id = ?", (pkg_id,))
        file_path = cursor.fetchone()[0]
        
        if not os.path.exists(file_path):
            print(f"\n❌ Package file not found: {file_path}")
            conn.close()
            return
        
        # Get list of online clients
        online_clients = [c for c in self.clients.values() if c.is_online()]
        
        if not online_clients:
            print("\n⚠️  No online clients available")
            conn.close()
            return
        
        # Display online clients
        print("\n📱 ONLINE CLIENTS:")
        for idx, client in enumerate(online_clients, 1):
            print(f"  [{idx}] {client.hostname} ({client.ip_address})")
        
        # Select target client
        try:
            client_choice = int(input("\nSelect Client # to target (0 to cancel): "))
            if client_choice == 0:
                conn.close()
                return
            if client_choice < 1 or client_choice > len(online_clients):
                print("Invalid client selection")
                conn.close()
                return
        except ValueError:
            print("Invalid input")
            conn.close()
            return
        
        target_client = online_clients[client_choice - 1]
        
        # Confirmation
        print("\n" + "="*70)
        print("🎯 DEPLOYMENT CONFIRMATION")
        print("="*70)
        print(f"Package:  {pkg_name} (v{pkg_version or 'Unknown'})")
        print(f"Size:     {pkg_size_mb:.2f} MB")
        print(f"Target:   {target_client.hostname} ({target_client.ip_address})")
        print(f"Method:   ENHANCED V4 (Chunked + SHA256 Verified)")
        print("="*70)
        
        confirm = input("\nProceed with deployment? (yes/no): ").strip().lower()
        if confirm != 'yes':
            print("✋ Deployment cancelled")
            conn.close()
            return
        
        # Start deployment with enhanced transfer
        print("\n" + "="*70)
        print("🚀 STARTING ENHANCED DEPLOYMENT")
        print("="*70)
        
        try:
            # Generate unique transfer ID
            transfer_id = f"deploy_{pkg_id}_{uuid.uuid4().hex[:8]}"
            
            # Get client socket
            client_socket = target_client.connection
            if not client_socket:
                print("❌ Client connection not available")
                # V9: Cleanup pending transfer
                with self.pending_transfers_lock:
                    self.pending_transfers.pop(transfer_id, None)
                conn.close()
                return
            
            # V8: Register pending transfer (separate transfer socket)
            # V9: Generate one-time security token
            import secrets
            transfer_token = secrets.token_hex(16)  # 32-char random token
            
            with self.pending_transfers_lock:
                self.pending_transfers[transfer_id] = {
                    'client_id': target_client.client_id,
                    'sock': None,
                    'token': transfer_token  # V9: Security token
                }
            
            # Send deployment command on CONTROL socket (with transfer_port)
            deploy_cmd = {
                'type': 'enhanced_package_deploy',
                'package_name': pkg_name,
                'transfer_id': transfer_id,
                'transfer_port': self.transfer_port,  # V8: Tell client which port to connect to
                'transfer_token': transfer_token  # V9: Security token for transfer channel
            }
            send_json_line(client_socket, deploy_cmd)
            
            # V8: Wait for client to connect to TRANSFER socket
            print(f"⏳ Waiting for transfer channel connection (port {self.transfer_port})...")
            transfer_sock = None
            deadline = time.time() + 30
            
            while time.time() < deadline:
                with self.pending_transfers_lock:
                    entry = self.pending_transfers.get(transfer_id)
                    if entry:
                        transfer_sock = entry.get('sock')
                if transfer_sock:
                    break
                time.sleep(0.1)
            
            if not transfer_sock:
                print("❌ Client did not connect to transfer channel in time")
                with self.pending_transfers_lock:
                    self.pending_transfers.pop(transfer_id, None)
                conn.close()
                return
            
            print(f"✅ Transfer channel connected")
            print(f"📊 Package: {format_bytes(os.path.getsize(file_path))}")
            print(f"🔒 Calculating SHA256 hash...")
            
            # V8: Create sender on TRANSFER socket (not control socket!)
            max_bandwidth = CONFIG.get('max_deployment_bandwidth', 0)
            if max_bandwidth == 0:
                max_bandwidth = None
            
            sender = ChunkedFileSender(
                transfer_sock,  # V8: Use transfer socket!
                max_bandwidth=max_bandwidth
            )
            
            # Progress callback for visual feedback
            last_percent = -1
            def progress_callback(sent_bytes, total_bytes):
                nonlocal last_percent
                pct = int((sent_bytes / total_bytes) * 100)
                if pct != last_percent and pct % 10 == 0:
                    bar_length = 50
                    filled = int(bar_length * sent_bytes / total_bytes)
                    bar = '█' * filled + '░' * (bar_length - filled)
                    print(f"\r📤 Transfer: [{bar}] {pct}% ({format_bytes(sent_bytes)}/{format_bytes(total_bytes)})", end='', flush=True)
                    last_percent = pct
            
            # V8: Send file on TRANSFER socket
            success = sender.send_file(
                file_path,
                transfer_id,
                progress_callback=progress_callback
            )
            
            # V8: Close transfer socket after send
            transfer_sock.close()
            
            # V8: Clean up pending transfer
            with self.pending_transfers_lock:
                self.pending_transfers.pop(transfer_id, None)
            
            print()  # New line after progress bar
            
            if success:
                print("\n✅ Enhanced deployment completed successfully!")
                print("   ✓ File sent in chunks (64KB)")
                print("   ✓ SHA256 verified by client")
                print("   ✓ Installation initiated")
                
                # Log deployment
                cursor.execute("""
                    INSERT INTO package_deployments 
                    (package_id, client_id, status, deploy_timestamp)
                    VALUES (?, ?, 'SUCCESS', datetime('now'))
                """, (pkg_id, target_client.client_id))
                conn.commit()
                
                # V7: Wait for installation result - FILTERED by transfer_id
                print("\n⏳ Waiting for installation result...")
                
                def is_install_result(m):
                    return (
                        m.get('transfer_id') == transfer_id
                        and m.get('status') in ('installed', 'failed')
                    )
                
                result_data = wait_for_message(
                    target_client,
                    predicate=is_install_result,
                    timeout=600,  # 10 minutes for install
                    on_ignored=lambda m: self._process_client_message(target_client, m)
                )
                
                if not result_data:
                    print("❌ Timeout waiting for installation result")
                    result_data = {'status': 'failed', 'error': 'Timeout'}
                
                if result_data.get('status') == 'installed':
                    print("✨ Package installed successfully!")
                    cursor.execute("""
                        UPDATE package_deployments 
                        SET status = 'INSTALLED', 
                            completion_timestamp = datetime('now'),
                            exit_code = ?
                        WHERE package_id = ? AND client_id = ?
                        ORDER BY deploy_timestamp DESC LIMIT 1
                    """, (result_data.get('exit_code', 0), pkg_id, target_client.client_id))
                    conn.commit()
                else:
                    print(f"❌ Installation failed: {result_data.get('error', 'Unknown error')}")
                    cursor.execute("""
                        UPDATE package_deployments 
                        SET status = 'FAILED',
                            error_message = ?
                        WHERE package_id = ? AND client_id = ?
                        ORDER BY deploy_timestamp DESC LIMIT 1
                    """, (result_data.get('error'), pkg_id, target_client.client_id))
                    conn.commit()
            else:
                print("\n❌ Enhanced deployment failed!")
                cursor.execute("""
                    INSERT INTO package_deployments 
                    (package_id, client_id, status, deploy_timestamp)
                    VALUES (?, ?, 'FAILED', datetime('now'))
                """, (pkg_id, target_client.client_id))
                conn.commit()
                
        except Exception as e:
            print(f"\n❌ Deployment error: {e}")
            logger.error(f"Deployment error: {e}", exc_info=True)
        finally:
            conn.close()
        
        print("="*70)

    def uninstall_software_interactive(self):
        """Interactive software removal wizard"""
        print("\n" + "="*70)
        print("🗑️  SOFTWARE UNINSTALL WIZARD")
        print("="*70)
        
        # Step 1: Select Client
        online_clients = [c for c in self.clients.values() if c.is_online()]
        
        if not online_clients:
            print("❌ No online clients available.")
            return
        
        print("\n🎯 Select Target Client:")
        for i, c in enumerate(online_clients, 1):
            print(f"  [{i}] 🟢 {c.hostname} ({c.ip_address}) - {c.software_count} packages")
        
        try:
            c_idx = input("\nSelect Client #: ").strip()
            target_client = online_clients[int(c_idx)-1]
        except (ValueError, IndexError):
            print("❌ Invalid selection")
            return
        
        # Step 2: Get software list for this client
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT software_name, software_version, vendor
            FROM software_inventory
            WHERE client_id = ?
            ORDER BY software_name
        """, (target_client.client_id,))
        
        software_list = cursor.fetchall()
        conn.close()
        
        if not software_list:
            print(f"❌ No software inventory available for {target_client.hostname}")
            print("   Trigger an inventory scan first.")
            return
        
        # Step 3: Select software to uninstall
        print(f"\n📦 Installed Software on {target_client.hostname}:")
        for i, (name, version, vendor) in enumerate(software_list, 1):
            print(f"  [{i}] {name} ({version}) - {vendor}")
        
        try:
            s_idx = input("\nSelect Software # to uninstall: ").strip()
            software_name, software_version, software_vendor = software_list[int(s_idx)-1]
        except (ValueError, IndexError):
            print("❌ Invalid selection")
            return
        
        # Step 4: Confirm
        print(f"\n⚠️  CONFIRM UNINSTALL:")
        print(f"   Software: {software_name} ({software_version})")
        print(f"   From: {target_client.hostname}")
        
        confirm = input("\nProceed? (yes/no): ").strip().lower()
        
        if confirm != 'yes':
            print("❌ Uninstall cancelled")
            return
        
        # Step 5: Send uninstall command
        try:
            cmd = {
                'type': 'software_uninstall',
                'software_name': software_name,
                'software_version': software_version
            }
            
            send_json_line(target_client.connection, cmd)
            print(f"\n✅ Uninstall command sent to {target_client.hostname}")
            print("   (Check client console for status)")
            
        except Exception as e:
            print(f"❌ Failed to send uninstall command: {e}")
    
    # FEATURE 3: WINDOWS USER ACCOUNT MANAGEMENT
    
    def create_user_account_interactive(self):
        """Interactive user account creation wizard"""
        print("\n" + "="*70)
        print("👤 CREATE WINDOWS USER ACCOUNT")
        print("="*70)
        
        # Step 1: Select target client(s)
        print("\n🎯 Target Selection:")
        print("  [1] Single Client")
        print("  [2] All Online Clients")
        
        scope = input("\nSelect scope: ").strip()
        
        online_clients = [c for c in self.clients.values() if c.is_online()]
        
        if not online_clients:
            print("❌ No online clients available.")
            return
        
        target_clients = []
        
        if scope == '1':
            # Single client
            print("\n📍 Select Target Client:")
            for i, c in enumerate(online_clients, 1):
                print(f"  [{i}] 🟢 {c.hostname} ({c.ip_address})")
            
            try:
                c_idx = input("\nSelect Client #: ").strip()
                target_clients = [online_clients[int(c_idx)-1]]
            except (ValueError, IndexError):
                print("❌ Invalid selection")
                return
        
        elif scope == '2':
            # All online clients
            target_clients = online_clients
            print(f"\n✅ Targeting all {len(target_clients)} online clients")
        
        else:
            print("❌ Invalid selection")
            return
        
        # Step 2: Get account details
        print("\n👤 Account Details:")
        username = input("Username: ").strip()
        
        if not username:
            print("❌ Username required")
            return
        
        password = getpass.getpass("Password: ")
        password_confirm = getpass.getpass("Confirm Password: ")
        
        if password != password_confirm:
            print("❌ Passwords do not match")
            return
        
        full_name = input("Full Name (optional): ").strip()
        description = input("Description (optional): ").strip()
        
        print("\n🔐 Account Type:")
        print("  [1] Standard User")
        print("  [2] Administrator")
        
        acct_type = input("Select type: ").strip()
        
        is_admin = (acct_type == '2')
        
        # Step 3: Confirm
        print(f"\n⚠️  CONFIRM USER CREATION:")
        print(f"   Username: {username}")
        print(f"   Type: {'Administrator' if is_admin else 'Standard User'}")
        print(f"   Targets: {len(target_clients)} client(s)")
        
        for client in target_clients:
            print(f"     • {client.hostname}")
        
        confirm = input("\nProceed? (yes/no): ").strip().lower()
        
        if confirm != 'yes':
            print("❌ Operation cancelled")
            return
        
        # Step 4: Deploy to clients
        print("\n" + "="*70)
        print("🚀 DEPLOYING USER ACCOUNT...")
        print("="*70)
        
        for client in target_clients:
            try:
                cmd = {
                    'type': 'user_account_create',
                    'username': username,
                    'password': password,
                    'full_name': full_name,
                    'description': description,
                    'is_admin': is_admin
                }
                
                send_json_line(client.connection, cmd)
                print(f"  ✅ Sent to {client.hostname}")
                
            except Exception as e:
                print(f"  ❌ Failed for {client.hostname}: {e}")
        
        print("\n✅ User creation commands dispatched!")
        print("   (Check client consoles for results)")
        print("="*70)
    
    def delete_user_account_interactive(self):
        """Interactive user account deletion wizard"""
        print("\n" + "="*70)
        print("🗑️  DELETE WINDOWS USER ACCOUNT")
        print("="*70)
        
        # Step 1: Select target client(s)
        print("\n🎯 Target Selection:")
        print("  [1] Single Client")
        print("  [2] All Online Clients")
        
        scope = input("\nSelect scope: ").strip()
        
        online_clients = [c for c in self.clients.values() if c.is_online()]
        
        if not online_clients:
            print("❌ No online clients available.")
            return
        
        target_clients = []
        
        if scope == '1':
            # Single client
            print("\n📍 Select Target Client:")
            for i, c in enumerate(online_clients, 1):
                print(f"  [{i}] 🟢 {c.hostname} ({c.ip_address})")
            
            try:
                c_idx = input("\nSelect Client #: ").strip()
                target_clients = [online_clients[int(c_idx)-1]]
            except (ValueError, IndexError):
                print("❌ Invalid selection")
                return
        
        elif scope == '2':
            # All online clients
            target_clients = online_clients
            print(f"\n✅ Targeting all {len(target_clients)} online clients")
        
        else:
            print("❌ Invalid selection")
            return
        
        # Step 2: Get username to delete
        username = input("\nUsername to DELETE: ").strip()
        
        if not username:
            print("❌ Username required")
            return
        
        # Step 3: Confirm (CRITICAL!)
        print(f"\n⚠️⚠️⚠️  DANGER - CONFIRM USER DELETION  ⚠️⚠️⚠️")
        print(f"   Username: {username}")
        print(f"   Targets: {len(target_clients)} client(s)")
        
        for client in target_clients:
            print(f"     • {client.hostname}")
        
        print("\n   This action CANNOT be undone!")
        
        confirm = input("\nType 'DELETE' to proceed: ").strip()
        
        if confirm != 'DELETE':
            print("❌ Operation cancelled")
            return
        
        # Step 4: Deploy deletion
        print("\n" + "="*70)
        print("🗑️  DELETING USER ACCOUNT...")
        print("="*70)
        
        for client in target_clients:
            try:
                cmd = {
                    'type': 'user_account_delete',
                    'username': username
                }
                
                send_json_line(client.connection, cmd)
                print(f"  ✅ Sent to {client.hostname}")
                
            except Exception as e:
                print(f"  ❌ Failed for {client.hostname}: {e}")
        
        print("\n✅ User deletion commands dispatched!")
        print("   (Check client consoles for results)")
        print("="*70)
    
    #
    # ================ MENU SYSTEM ================
    #
    
    def show_main_menu(self):
        """Display main menu"""
        stats = self.get_statistics()
        
        print("\n" + "="*70)
        print("N2NHU NETWORK COMMAND CENTER - V3 ENHANCED")
        print("="*70)
        print(f"\n📊 Status:")
        print(f"   Clients: {stats['online_clients']}/{stats['total_clients']} online")
        print(f"   Credentials Configured: {stats['clients_with_credentials']}")
        print(f"   Inventory Available: {stats['clients_with_inventory']}")
        
        print("\n🔧 MAIN MENU:")
        print("  1. View Client List")
        print("  2. View Inventory Summary")
        print("  3. 🔄 REFRESH SOFTWARE INVENTORY (All Clients)")
        print("")
        print("  📦 PACKAGE DEPLOYMENT:")
        print("  4. View Deployable Packages")
        print("  5. Import MSI Package")
        print("  6. Deploy Package to Client")
        print("")
        print("  🗑️  SOFTWARE MANAGEMENT:")
        print("  7. Uninstall Software from Client")
        print("")
        print("  👤 USER ACCOUNT MANAGEMENT:")
        print("  8. Create Windows User Account")
        print("  9. Delete Windows User Account")
        print("")
        print("  10. View Operations Log")
        print("  11. View Statistics")
        print("")
        print("  📡 VPN/NETWORK:")
        print("  12. Configure VPN/DHCP (IP Assignment)")
        print("")
        print("  13. Exit")
        print("\nSelect option (1-13): ", end='')
    
    def interactive_menu(self):
        """Interactive menu loop"""
        while self.running:
            self.show_main_menu()
            
            try:
                choice = input().strip()
                
                if choice == '1':
                    self.view_client_list()
                elif choice == '2':
                    self.view_inventory_summary()
                elif choice == '3':
                    self.trigger_inventory_refresh_all()
                elif choice == '4':
                    self.view_deployables()
                elif choice == '5':
                    self.import_msi_package()
                elif choice == '6':
                    self.deploy_software_interactive()
                elif choice == '7':
                    self.uninstall_software_interactive()
                elif choice == '8':
                    self.create_user_account_interactive()
                elif choice == '9':
                    self.delete_user_account_interactive()
                elif choice == '10':
                    self.view_operations_log()
                elif choice == '11':
                    self.view_detailed_statistics()
                elif choice == '12':
                    # VPN/DHCP Configuration Menu
                    dhcp_menu.configure_vpn_dhcp_menu(self)
                elif choice == '13':
                    print("\n🛑 Shutting down server...")
                    self.stop_server()
                    break
                else:
                    print("Invalid option. Please try again.")
                
                input("\nPress Enter to continue...")
                
            except KeyboardInterrupt:
                print("\n\n🛑 Shutting down server...")
                self.stop_server()
                break
    
    def view_client_list(self):
        """View all registered clients with HARDWARE SPECS"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        print("\n" + "="*105)
        print("REGISTERED ASSETS - COMPLETE HARDWARE & STATUS")
        print("="*105)
        
        cursor.execute("""
            SELECT hostname, ip_address, status, cpu_info, ram_info, disk_info, credentials_configured
            FROM clients
            ORDER BY hostname
        """)
        rows = cursor.fetchall()

        if not rows:
            print("No clients registered yet.")
        else:
            print(f"\n{'Hostname':<16} {'IP':<15} {'Stat':<5} {'CPU':<28} {'RAM':<10} {'Disk (C:)':<22} {'Creds'}")
            print("-"*105)
            
            for row in rows:
                hostname, ip, status_val, cpu, ram, disk, creds = row
                
                icon = "🟢" if status_val == "online" else "🔴"
                cpu_display = (cpu[:26] + '..') if cpu and len(cpu) > 26 else (cpu or "N/A")
                creds_icon = "✅" if creds else "❌"
                
                print(f"{hostname:<16} {ip:<15} {icon:<5} {cpu_display:<28} {ram or 'N/A':<10} {disk or 'N/A':<22} {creds_icon}")
        
        print("="*105)
        print(f"\nTotal Assets: {len(rows)}")
        print("="*105)
        
        conn.close()
    
    def view_operations_log(self):
        """View recent operations"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT operation_type, client_id, status, timestamp
            FROM operations_log
            ORDER BY timestamp DESC
            LIMIT 20
        """)
        
        print("\n" + "="*70)
        print("RECENT OPERATIONS (Last 20)")
        print("="*70)
        
        for op_type, client_id, status, timestamp in cursor.fetchall():
            print(f"{timestamp[:19]} | {op_type:<20} | {client_id:<20} | {status}")
        
        print("="*70)
        conn.close()
    
    def view_detailed_statistics(self):
        """View detailed statistics"""
        stats = self.get_statistics()
        
        print("\n" + "="*70)
        print("DETAILED STATISTICS")
        print("="*70)
        print(f"\nClients:")
        print(f"  Total: {stats['total_clients']}")
        print(f"  Online: {stats['online_clients']}")
        print(f"  Offline: {stats['offline_clients']}")
        print(f"  With Credentials: {stats['clients_with_credentials']}")
        print(f"  With Inventory: {stats['clients_with_inventory']}")
        print(f"\nOperations:")
        print(f"  Processed: {stats['operations_processed']}")
        print(f"  Succeeded: {stats['operations_succeeded']}")
        print(f"  Failed: {stats['operations_failed']}")
        print("="*70)
    
    def stop_server(self):
        """Stop the server"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        logger.info("🛑 Server stopped")


def main():
    """Main entry point"""
    print("""
    ╔══════════════════════════════════════════════════════════════════╗
    ║                                                                  ║
    ║         N2NHU NETWORK COMMAND SERVER - V3 ENHANCED               ║
    ║      Universal Network & Endpoint Management Platform            ║
    ║                                                                  ║
    ║    V3 ENHANCEMENTS:                                              ║
    ║    • Complete Hardware Inventory (CPU, RAM, Disk)                ║
    ║    • MSI Package Import & Deployment                             ║
    ║    • Windows User Account Management                             ║
    ║    • Software Uninstallation                                     ║
    ║    • Credential Management (Domain/Local Admin)                  ║
    ║    • WMIC Software Inventory Integration                         ║
    ║    • Full Database Audit Trail                                   ║
    ║                                                                  ║
    ║    Based on proven transformation architecture                   ║
    ║                                                                  ║
    ╚══════════════════════════════════════════════════════════════════╝
    """)
    
    # Create server instance (will collect credentials at startup unless configured to skip)
    server = NetworkManagementServer(
        config_path="config",
        db_path=CONFIG['db_path']  # Use configured database path
    )
    
    # Start server (will use config values for host/port if not specified)
    server.start_server()
    
    # Give server a moment to start
    time.sleep(1)
    
    # Run interactive menu
    try:
        server.interactive_menu()
    except KeyboardInterrupt:
        print("\n\n🛑 Shutting down server...")
        server.stop_server()
        print("✅ Server stopped")


if __name__ == "__main__":
    main()
