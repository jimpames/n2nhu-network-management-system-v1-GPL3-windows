# ENHANCED INVENTORY BROWSER - Add to v12-nms-server-PRODUCTION.py
# Insert this method into the NMSServer class (around line 1150)

def browse_inventory_interactive(self):
    """Interactive inventory browser with pagination and search"""
    while True:
        print("\n" + "="*70)
        print("📊 INVENTORY BROWSER")
        print("="*70)
        print("\n📋 OPTIONS:")
        print("  1. Database Summary")
        print("  2. Browse by Client (paginated)")
        print("  3. Search Software (by name/vendor)")
        print("  4. Find Software Distribution (where is X installed?)")
        print("  5. Top 20 Most Common Software")
        print("  6. Back to Main Menu")
        
        choice = input("\nSelect option (1-6): ").strip()
        
        if choice == '1':
            self._show_database_summary()
        elif choice == '2':
            self._browse_by_client()
        elif choice == '3':
            self._search_software()
        elif choice == '4':
            self._find_software_distribution()
        elif choice == '5':
            self._show_top_software()
        elif choice == '6':
            break
        else:
            print("Invalid option. Please try again.")

def _show_database_summary(self):
    """Show detailed database statistics"""
    conn = sqlite3.connect(self.db_path)
    cursor = conn.cursor()
    
    # Get stats
    cursor.execute("SELECT COUNT(*) FROM clients")
    total_clients = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM software_inventory")
    total_software = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(DISTINCT software_name) FROM software_inventory")
    unique_software = cursor.fetchone()[0]
    
    cursor.execute("""
        SELECT COUNT(DISTINCT hostname) 
        FROM software_inventory 
        WHERE software_name IS NOT NULL
    """)
    clients_with_inventory = cursor.fetchone()[0]
    
    cursor.execute("SELECT MAX(scanned_at) FROM software_inventory")
    latest_scan = cursor.fetchone()[0]
    
    print("\n" + "="*70)
    print("📊 DATABASE SUMMARY")
    print("="*70)
    print(f"\n📁 Database: {self.db_path}")
    print(f"🖥️  Total Clients: {total_clients}")
    print(f"📦 Total Software Records: {total_software:,}")
    print(f"🔢 Unique Software Titles: {unique_software:,}")
    print(f"✅ Clients with Inventory: {clients_with_inventory}")
    if latest_scan:
        print(f"🕐 Latest Scan: {latest_scan}")
    print("="*70)
    
    conn.close()

def _browse_by_client(self):
    """Browse software by client with pagination"""
    conn = sqlite3.connect(self.db_path)
    cursor = conn.cursor()
    
    # Show clients first
    cursor.execute("""
        SELECT c.hostname, COUNT(s.id) as software_count
        FROM clients c
        LEFT JOIN software_inventory s ON c.hostname = s.hostname
        GROUP BY c.hostname
        ORDER BY c.hostname
    """)
    clients = cursor.fetchall()
    
    if not clients:
        print("\n❌ No clients in database")
        conn.close()
        return
    
    print("\n" + "="*70)
    print("🖥️  SELECT CLIENT")
    print("="*70)
    for i, (hostname, count) in enumerate(clients, 1):
        print(f"  {i}. {hostname} ({count} packages)")
    
    choice = input(f"\nSelect client (1-{len(clients)}) or Q to cancel: ").strip()
    if choice.upper() == 'Q':
        conn.close()
        return
    
    try:
        idx = int(choice) - 1
        hostname = clients[idx][0]
    except (ValueError, IndexError):
        print("❌ Invalid selection")
        conn.close()
        return
    
    # Get total count for pagination
    cursor.execute("""
        SELECT COUNT(*) FROM software_inventory WHERE hostname = ?
    """, (hostname,))
    total = cursor.fetchone()[0]
    
    if total == 0:
        print(f"\n❌ No software inventory for {hostname}")
        conn.close()
        return
    
    # Paginate through software
    page_size = 20
    page = 0
    total_pages = (total + page_size - 1) // page_size
    
    while True:
        offset = page * page_size
        
        cursor.execute("""
            SELECT software_name, version, vendor
            FROM software_inventory
            WHERE hostname = ?
            ORDER BY software_name
            LIMIT ? OFFSET ?
        """, (hostname, page_size, offset))
        
        results = cursor.fetchall()
        
        print("\n" + "="*100)
        print(f"📦 SOFTWARE ON: {hostname}")
        print(f"    Page {page + 1} of {total_pages} | Total: {total} packages")
        print("="*100)
        print(f"\n{'Software':<50} {'Version':<20} {'Vendor':<30}")
        print("-"*100)
        
        for name, version, vendor in results:
            name = (name[:47] + '...') if name and len(name) > 50 else (name or 'N/A')
            version = (version[:17] + '...') if version and len(version) > 20 else (version or 'N/A')
            vendor = (vendor[:27] + '...') if vendor and len(vendor) > 30 else (vendor or 'N/A')
            print(f"{name:<50} {version:<20} {vendor:<30}")
        
        print("-"*100)
        
        if total_pages > 1:
            print("\n[N]ext page | [P]revious page | [Q]uit")
            nav = input("Select: ").strip().upper()
            
            if nav == 'N' and page < total_pages - 1:
                page += 1
            elif nav == 'P' and page > 0:
                page -= 1
            elif nav == 'Q' or nav == '':
                break
            else:
                if nav == 'N':
                    print("⚠️  Already on last page")
                elif nav == 'P':
                    print("⚠️  Already on first page")
        else:
            break
    
    conn.close()

def _search_software(self):
    """Search for software by name or vendor"""
    search_term = input("\n🔍 Enter software name or vendor to search: ").strip()
    
    if not search_term:
        print("❌ Search term required")
        return
    
    conn = sqlite3.connect(self.db_path)
    cursor = conn.cursor()
    search_pattern = f"%{search_term}%"
    
    cursor.execute("""
        SELECT COUNT(*) FROM software_inventory 
        WHERE software_name LIKE ? OR vendor LIKE ?
    """, (search_pattern, search_pattern))
    total = cursor.fetchone()[0]
    
    if total == 0:
        print(f"\n❌ No software found matching '{search_term}'")
        conn.close()
        return
    
    # Paginate
    page_size = 20
    page = 0
    total_pages = (total + page_size - 1) // page_size
    
    while True:
        offset = page * page_size
        
        cursor.execute("""
            SELECT hostname, software_name, version, vendor
            FROM software_inventory
            WHERE software_name LIKE ? OR vendor LIKE ?
            ORDER BY hostname, software_name
            LIMIT ? OFFSET ?
        """, (search_pattern, search_pattern, page_size, offset))
        
        results = cursor.fetchall()
        
        print("\n" + "="*110)
        print(f"🔍 SEARCH RESULTS: '{search_term}'")
        print(f"    Page {page + 1} of {total_pages} | Total: {total} matches")
        print("="*110)
        print(f"\n{'Hostname':<20} {'Software':<45} {'Version':<20} {'Vendor':<25}")
        print("-"*110)
        
        for hostname, name, version, vendor in results:
            hostname = hostname or 'N/A'
            name = (name[:42] + '...') if name and len(name) > 45 else (name or 'N/A')
            version = (version[:17] + '...') if version and len(version) > 20 else (version or 'N/A')
            vendor = (vendor[:22] + '...') if vendor and len(vendor) > 25 else (vendor or 'N/A')
            
            print(f"{hostname:<20} {name:<45} {version:<20} {vendor:<25}")
        
        print("-"*110)
        
        if total_pages > 1:
            print("\n[N]ext page | [P]revious page | [Q]uit")
            nav = input("Select: ").strip().upper()
            
            if nav == 'N' and page < total_pages - 1:
                page += 1
            elif nav == 'P' and page > 0:
                page -= 1
            elif nav == 'Q' or nav == '':
                break
        else:
            break
    
    conn.close()

def _find_software_distribution(self):
    """Find which clients have a specific software"""
    software = input("\n📊 Enter exact software name: ").strip()
    
    if not software:
        print("❌ Software name required")
        return
    
    conn = sqlite3.connect(self.db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT hostname, version, vendor, install_date
        FROM software_inventory
        WHERE software_name = ?
        ORDER BY hostname
    """, (software,))
    
    results = cursor.fetchall()
    
    if not results:
        print(f"\n❌ '{software}' not found on any client")
        conn.close()
        return
    
    print("\n" + "="*100)
    print(f"📊 DISTRIBUTION: {software}")
    print(f"    Found on {len(results)} client(s)")
    print("="*100)
    print(f"\n{'Hostname':<20} {'Version':<20} {'Vendor':<30} {'Install Date'}")
    print("-"*100)
    
    for hostname, version, vendor, install_date in results:
        hostname = hostname or 'N/A'
        version = version or 'N/A'
        vendor = vendor or 'N/A'
        install_date = install_date or 'N/A'
        
        print(f"{hostname:<20} {version:<20} {vendor:<30} {install_date}")
    
    print("-"*100)
    conn.close()

def _show_top_software(self):
    """Show most common software across all clients"""
    conn = sqlite3.connect(self.db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT software_name, COUNT(DISTINCT hostname) as client_count
        FROM software_inventory
        WHERE software_name IS NOT NULL
        GROUP BY software_name
        ORDER BY client_count DESC, software_name
        LIMIT 20
    """)
    
    results = cursor.fetchall()
    
    if not results:
        print("\n❌ No software inventory data")
        conn.close()
        return
    
    print("\n" + "="*90)
    print("🏆 TOP 20 MOST COMMON SOFTWARE")
    print("="*90)
    print(f"\n{'Software Name':<70} {'Clients':<10}")
    print("-"*90)
    
    for name, count in results:
        name = (name[:67] + '...') if len(name) > 70 else name
        print(f"{name:<70} {count:<10}")
    
    print("-"*90)
    conn.close()
