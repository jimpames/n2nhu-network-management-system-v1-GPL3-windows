"""VPN/DHCP Configuration Menu for V10"""

def configure_vpn_dhcp_menu(nms_server):
    """Interactive VPN/DHCP configuration menu"""
    from network_utils import list_network_adapters, get_adapter_network, suggest_ip_pool, validate_ip
    
    while True:
        print("\n" + "="*70)
        print("VPN/DHCP CONFIGURATION")
        print("="*70)
        
        if nms_server.dhcp_server:
            config = nms_server.dhcp_server.config
            print(f"\nCurrent Configuration:")
            print(f"  Status: {'ENABLED ✅' if config.get('enabled') else 'DISABLED ❌'}")
            print(f"  Bridge Interface: {config.get('interface_name', 'Not set')}")
            print(f"  Network: {config.get('network', 'Not set')}/{config.get('subnet_mask', 'Not set')}")
            print(f"  Gateway: {config.get('gateway', 'Not set')}")
            print(f"  IP Pool: {config.get('pool_start', 'Not set')} - {config.get('pool_end', 'Not set')}")
            
            # Calculate pool size
            try:
                start = config.get('pool_start', '').split('.')
                end = config.get('pool_end', '').split('.')
                if len(start) == 4 and len(end) == 4:
                    pool_size = int(end[3]) - int(start[3]) + 1
                    print(f"  Pool Size: {pool_size} addresses")
            except:
                pass
            
            dns_list = config.get('dns_servers', [])
            if dns_list:
                print(f"  DNS Servers: {', '.join(dns_list)}")
        else:
            print("\n⚠️  DHCP Server not initialized")
            return
        
        print("\nOptions:")
        print("  1. List Network Adapters (Choose Bridge Interface)")
        print("  2. Configure IP Pool Range")
        print("  3. Set Gateway Address")
        print("  4. Configure DNS Servers")
        print("  5. View Active VPN Clients")
        print("  6. View IP Lease Table")
        print("  7. Enable/Disable DHCP")
        print("  8. Test Configuration")
        print("  9. Back to Main Menu")
        print("\nSelect option (1-9): ", end='')
        
        choice = input().strip()
        
        if choice == '1':
            list_and_select_adapter(nms_server)
        elif choice == '2':
            configure_ip_pool(nms_server)
        elif choice == '3':
            configure_gateway(nms_server)
        elif choice == '4':
            configure_dns(nms_server)
        elif choice == '5':
            view_active_vpn_clients(nms_server)
        elif choice == '6':
            view_ip_lease_table(nms_server)
        elif choice == '7':
            toggle_dhcp(nms_server)
        elif choice == '8':
            test_dhcp_configuration(nms_server)
        elif choice == '9':
            break
        else:
            print("Invalid option. Please try again.")
        
        if choice != '9':
            input("\nPress Enter to continue...")

def list_and_select_adapter(nms_server):
    """List network adapters and select bridge interface"""
    from network_utils import list_network_adapters, get_adapter_network, suggest_ip_pool
    
    print("\n" + "="*70)
    print("NETWORK ADAPTERS ON SERVER")
    print("="*70)
    
    adapters = list_network_adapters()
    
    if not adapters:
        print("⚠️  No network adapters found!")
        return
    
    for idx, adapter in enumerate(adapters, 1):
        status_icon = "✅" if adapter['status'] == 'Active' else "❌"
        print(f"  [{idx}] {adapter['name']}")
        print(f"      IP: {adapter['ip']}")
        print(f"      Status: {adapter['status']} {status_icon}")
    
    print(f"\nSelect adapter for VPN bridge (1-{len(adapters)}, 0 to cancel): ", end='')
    choice = input().strip()
    
    try:
        choice_num = int(choice)
        if choice_num == 0:
            return
        if choice_num < 1 or choice_num > len(adapters):
            print("Invalid selection!")
            return
        
        selected = adapters[choice_num - 1]
        
        # Update DHCP config
        nms_server.dhcp_server.config['interface_name'] = selected['name']
        
        # Suggest network settings based on adapter IP
        network = get_adapter_network(selected['ip'])
        if network:
            nms_server.dhcp_server.config['network'] = network
            print(f"\n✅ Bridge interface set to: {selected['name']}")
            print(f"   Network detected: {network}")
            
            # Suggest IP pool
            pool_start, pool_end = suggest_ip_pool(network)
            if pool_start and pool_end:
                print(f"   Suggested IP pool: {pool_start} - {pool_end}")
                print("\nApply suggested pool? (y/n): ", end='')
                if input().strip().lower() == 'y':
                    nms_server.dhcp_server.config['pool_start'] = pool_start
                    nms_server.dhcp_server.config['pool_end'] = pool_end
                    
                    # Set gateway to .1 of network
                    octets = network.split('.')
                    gateway = f"{octets[0]}.{octets[1]}.{octets[2]}.1"
                    nms_server.dhcp_server.config['gateway'] = gateway
                    print(f"   Gateway set to: {gateway}")
        
        nms_server.dhcp_server.save_config()
        print("\n✅ Configuration saved!")
        
    except ValueError:
        print("Invalid input!")

def configure_ip_pool(nms_server):
    """Configure DHCP IP pool range"""
    from network_utils import validate_ip
    
    print("\n" + "="*70)
    print("CONFIGURE IP POOL")
    print("="*70)
    
    current_start = nms_server.dhcp_server.config.get('pool_start', '')
    current_end = nms_server.dhcp_server.config.get('pool_end', '')
    
    print(f"\nCurrent pool: {current_start} - {current_end}")
    print(f"Network: {nms_server.dhcp_server.config.get('network', 'Not set')}")
    print(f"Subnet: {nms_server.dhcp_server.config.get('subnet_mask', '255.255.255.0')}")
    
    print(f"\nEnter pool start IP [{current_start}]: ", end='')
    start_input = input().strip()
    pool_start = start_input if start_input else current_start
    
    if not validate_ip(pool_start):
        print("❌ Invalid IP address!")
        return
    
    print(f"Enter pool end IP [{current_end}]: ", end='')
    end_input = input().strip()
    pool_end = end_input if end_input else current_end
    
    if not validate_ip(pool_end):
        print("❌ Invalid IP address!")
        return
    
    # Validate range
    try:
        start_octets = pool_start.split('.')
        end_octets = pool_end.split('.')
        
        if start_octets[0:3] != end_octets[0:3]:
            print("❌ Start and end must be in same /24 network!")
            return
        
        if int(start_octets[3]) >= int(end_octets[3]):
            print("❌ Start IP must be less than end IP!")
            return
        
        pool_size = int(end_octets[3]) - int(start_octets[3]) + 1
        
        nms_server.dhcp_server.config['pool_start'] = pool_start
        nms_server.dhcp_server.config['pool_end'] = pool_end
        nms_server.dhcp_server.save_config()
        
        print(f"\n✅ IP Pool updated!")
        print(f"   Range: {pool_start} - {pool_end}")
        print(f"   Size: {pool_size} addresses")
        
    except Exception as e:
        print(f"❌ Error: {e}")

def configure_gateway(nms_server):
    """Configure gateway address"""
    from network_utils import validate_ip
    
    print("\n" + "="*70)
    print("CONFIGURE GATEWAY")
    print("="*70)
    
    current = nms_server.dhcp_server.config.get('gateway', '')
    print(f"\nCurrent gateway: {current}")
    print(f"Enter gateway IP [{current}]: ", end='')
    
    gateway_input = input().strip()
    gateway = gateway_input if gateway_input else current
    
    if not validate_ip(gateway):
        print("❌ Invalid IP address!")
        return
    
    nms_server.dhcp_server.config['gateway'] = gateway
    nms_server.dhcp_server.save_config()
    print(f"\n✅ Gateway set to: {gateway}")

def configure_dns(nms_server):
    """Configure DNS servers"""
    from network_utils import validate_ip
    
    print("\n" + "="*70)
    print("CONFIGURE DNS SERVERS")
    print("="*70)
    
    current = nms_server.dhcp_server.config.get('dns_servers', [])
    print(f"\nCurrent DNS servers: {', '.join(current) if current else 'None'}")
    print("\nEnter DNS servers (comma-separated, e.g., 8.8.8.8,8.8.4.4): ", end='')
    
    dns_input = input().strip()
    if not dns_input:
        return
    
    dns_list = [ip.strip() for ip in dns_input.split(',')]
    
    # Validate all IPs
    for ip in dns_list:
        if not validate_ip(ip):
            print(f"❌ Invalid IP address: {ip}")
            return
    
    nms_server.dhcp_server.config['dns_servers'] = dns_list
    nms_server.dhcp_server.save_config()
    print(f"\n✅ DNS servers set to: {', '.join(dns_list)}")

def view_active_vpn_clients(nms_server):
    """View active VPN clients"""
    print("\n" + "="*70)
    print("ACTIVE VPN CLIENTS")
    print("="*70)
    
    try:
        import sqlite3
        conn = sqlite3.connect(nms_server.db_path)
        c = conn.cursor()
        
        c.execute('''SELECT client_id, hostname, vpn_ip, wan_ip, connected_at, status 
                     FROM vpn_clients 
                     WHERE status = 'ONLINE'
                     ORDER BY connected_at DESC''')
        
        clients = c.fetchall()
        conn.close()
        
        if not clients:
            print("\n  No active VPN clients")
            return
        
        print(f"\n  Total: {len(clients)} active")
        print("\n  Client ID          | Hostname        | VPN IP        | WAN IP        | Status")
        print("  " + "-"*90)
        
        for client in clients:
            print(f"  {client[0][:18]:<18} | {client[1][:15]:<15} | {client[2]:<13} | {client[3]:<13} | {client[5]}")
            
    except Exception as e:
        print(f"❌ Error: {e}")

def view_ip_lease_table(nms_server):
    """View IP lease table"""
    print("\n" + "="*70)
    print("IP LEASE TABLE")
    print("="*70)
    
    try:
        import sqlite3
        conn = sqlite3.connect(nms_server.db_path)
        c = conn.cursor()
        
        c.execute('''SELECT client_id, hostname, vpn_ip, mac_address, lease_expires, status 
                     FROM vpn_clients 
                     ORDER BY vpn_ip''')
        
        leases = c.fetchall()
        conn.close()
        
        if not leases:
            print("\n  No leases allocated")
            return
        
        print(f"\n  Total: {len(leases)} leases")
        print("\n  VPN IP        | Client ID          | Hostname        | Status    | Expires")
        print("  " + "-"*90)
        
        for lease in leases:
            expires = lease[4][:19] if lease[4] else 'N/A'
            print(f"  {lease[2]:<13} | {lease[0][:18]:<18} | {lease[1][:15]:<15} | {lease[5]:<9} | {expires}")
            
    except Exception as e:
        print(f"❌ Error: {e}")

def toggle_dhcp(nms_server):
    """Enable/disable DHCP server"""
    print("\n" + "="*70)
    print("ENABLE/DISABLE DHCP")
    print("="*70)
    
    current = nms_server.dhcp_server.config.get('enabled', False)
    status = "ENABLED" if current else "DISABLED"
    
    print(f"\nCurrent status: {status}")
    print(f"Change to {'DISABLED' if current else 'ENABLED'}? (y/n): ", end='')
    
    if input().strip().lower() == 'y':
        nms_server.dhcp_server.config['enabled'] = not current
        nms_server.dhcp_server.save_config()
        new_status = "ENABLED ✅" if not current else "DISABLED ❌"
        print(f"\n✅ DHCP server {new_status}")

def test_dhcp_configuration(nms_server):
    """Test DHCP configuration"""
    print("\n" + "="*70)
    print("TEST DHCP CONFIGURATION")
    print("="*70)
    
    config = nms_server.dhcp_server.config
    issues = []
    
    print("\nChecking configuration...")
    
    # Check enabled
    if not config.get('enabled'):
        issues.append("❌ DHCP is DISABLED")
    else:
        print("✅ DHCP is enabled")
    
    # Check interface
    if not config.get('interface_name'):
        issues.append("❌ No bridge interface selected")
    else:
        print(f"✅ Bridge interface: {config['interface_name']}")
    
    # Check network
    if not config.get('network'):
        issues.append("❌ Network not configured")
    else:
        print(f"✅ Network: {config['network']}/{config.get('subnet_mask', '255.255.255.0')}")
    
    # Check pool
    if not config.get('pool_start') or not config.get('pool_end'):
        issues.append("❌ IP pool not configured")
    else:
        try:
            start = config['pool_start'].split('.')
            end = config['pool_end'].split('.')
            size = int(end[3]) - int(start[3]) + 1
            print(f"✅ IP pool: {config['pool_start']} - {config['pool_end']} ({size} addresses)")
        except:
            issues.append("❌ Invalid IP pool range")
    
    # Check gateway
    if not config.get('gateway'):
        issues.append("⚠️  No gateway configured")
    else:
        print(f"✅ Gateway: {config['gateway']}")
    
    # Check DNS
    if not config.get('dns_servers'):
        issues.append("⚠️  No DNS servers configured")
    else:
        print(f"✅ DNS: {', '.join(config['dns_servers'])}")
    
    if issues:
        print("\n⚠️  Issues found:")
        for issue in issues:
            print(f"  {issue}")
    else:
        print("\n✅ Configuration looks good!")
        print("   Ready to assign IPs to VPN clients")
