#!/usr/bin/env python3
"""
N2NHU VPN Server - Automated Setup Script (UPDATED for tapctl.exe)

This script automates the complete server installation and configuration:
1. Checks prerequisites
2. Installs Python dependencies
3. Detects TAP driver (modern tapctl.exe or legacy tapinstall.exe)
4. Configures network interfaces
5. Creates database
6. Sets up NGROK tunnel
"""

import subprocess
import sys
import os
import urllib.request
import zipfile
import configparser
import platform

class ServerSetup:
    def __init__(self):
        self.config = configparser.ConfigParser()
        self.config.read('nms_server_config.ini')
        self.use_modern_tap = False  # Flag for tapctl.exe vs tapinstall.exe
        self.tap_installer = None
        
    def check_windows(self):
        """Verify running on Windows"""
        if platform.system() != 'Windows':
            print("="*70)
            print("ERROR: This server requires Windows")
            print("="*70)
            print("The TAP adapter and network bridging features require Windows.")
            print("For Linux/Mac servers, please use the OpenVPN-based version.")
            return False
        
        print("[CHECK] ✓ Running on Windows")
        return True
    
    def check_admin(self):
        """Check if running with administrator privileges"""
        try:
            import ctypes
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
            if not is_admin:
                print("\n" + "="*70)
                print("ERROR: Administrator privileges required")
                print("="*70)
                print("Please run this script as Administrator:")
                print("1. Right-click on Command Prompt")
                print("2. Select 'Run as administrator'")
                print("3. Navigate to this directory and run again")
                return False
            
            print("[CHECK] ✓ Running with Administrator privileges")
            return True
        except:
            print("[WARNING] Could not verify admin privileges")
            return True
    
    def check_python_version(self):
        """Verify Python version >= 3.7"""
        version = sys.version_info
        if version.major < 3 or (version.major == 3 and version.minor < 7):
            print(f"[ERROR] Python 3.7+ required (found {version.major}.{version.minor})")
            return False
        
        print(f"[CHECK] ✓ Python {version.major}.{version.minor}.{version.micro}")
        return True
    
    def install_dependencies(self):
        """Install Python dependencies"""
        print("\n[STEP 1] Installing Python dependencies...")
        
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'],
                         check=True)
            print("[SUCCESS] ✓ Dependencies installed")
            return True
        except Exception as e:
            print(f"[ERROR] Dependency installation failed: {e}")
            return False
    
    def check_tap_driver(self):
        """Check if TAP driver tools are available (modern or legacy)"""
        print("\n[STEP 2] Checking TAP driver tools...")
        
        # Check for modern tapctl.exe (OpenVPN 2.4+)
        modern_paths = [
            r"C:\Program Files\OpenVPN\bin\tapctl.exe",
            r"C:\Program Files (x86)\OpenVPN\bin\tapctl.exe",
            "tapctl.exe"
        ]
        
        for path in modern_paths:
            if os.path.exists(path):
                self.tap_installer = path
                self.use_modern_tap = True
                print(f"[SUCCESS] ✓ Modern TAP tool found: {path}")
                print("[INFO] Using tapctl.exe (OpenVPN 2.4+)")
                return True
        
        # Check for legacy tapinstall.exe (OpenVPN 2.3 and earlier)
        legacy_paths = [
            r"C:\Program Files\TAP-Windows\bin\tapinstall.exe",
            r"C:\Program Files (x86)\TAP-Windows\bin\tapinstall.exe",
            "tapinstall.exe"
        ]
        
        for path in legacy_paths:
            if os.path.exists(path):
                self.tap_installer = path
                self.use_modern_tap = False
                print(f"[SUCCESS] ✓ Legacy TAP tool found: {path}")
                print("[INFO] Using tapinstall.exe (OpenVPN 2.3)")
                return True
        
        # Neither found
        print("[INFO] TAP driver tools not found")
        print("\n" + "="*70)
        print("TAP DRIVER INSTALLATION")
        print("="*70)
        print("OpenVPN installation detected but TAP tools not found.")
        print("")
        print("The TAP adapter should already be installed by OpenVPN.")
        print("You can verify by running: ipconfig /all")
        print("Look for 'TAP-Windows Adapter V9'")
        print("")
        print("If you don't see it, reinstall OpenVPN:")
        print("1. Download: https://openvpn.net/community-downloads/")
        print("2. Run installer, ensure 'TAP Virtual Ethernet Adapter' is selected")
        print("3. Complete installation")
        print("="*70)
        
        # Ask if they want to continue anyway
        choice = input("\nTAP adapter should already be installed. Continue? [y/N]: ").strip().lower()
        return choice == 'y'
    
    def check_tap_adapter_exists(self):
        """Check if TAP adapter already exists using ipconfig"""
        print("\n[STEP 3] Checking for existing TAP adapter...")
        
        try:
            result = subprocess.run(['ipconfig', '/all'], 
                                  capture_output=True, 
                                  text=True,
                                  encoding='cp1252')
            
            # Look for TAP adapter in output
            if 'TAP-Windows' in result.stdout or 'tap0901' in result.stdout.lower():
                print("[SUCCESS] ✓ TAP adapter already installed!")
                print("[INFO] Adapter name will be configured in network bridge setup")
                return True
            else:
                print("[INFO] No TAP adapter found")
                return False
                
        except Exception as e:
            print(f"[WARNING] Could not check for TAP adapter: {e}")
            return False
    
    def setup_database(self):
        """Initialize database"""
        print("\n[STEP 4] Setting up database...")
        
        db_path = self.config.get('database', 'path', fallback='network_mgmt.db')
        
        try:
            # Import and initialize database from virtual_dhcp_v12
            from virtual_dhcp_v12 import VirtualDHCPServer
            
            dhcp = VirtualDHCPServer(db_path)
            
            # Save default configuration
            dhcp.config['enabled'] = self.config.getboolean('dhcp', 'enabled', fallback=True)
            dhcp.config['interface_name'] = self.config.get('dhcp', 'bridge_interface', fallback='Ethernet1')
            dhcp.config['network'] = self.config.get('dhcp', 'network', fallback='192.168.1.0')
            dhcp.config['subnet_mask'] = self.config.get('dhcp', 'subnet_mask', fallback='255.255.255.0')
            dhcp.config['gateway'] = self.config.get('dhcp', 'gateway', fallback='192.168.1.1')
            dhcp.config['pool_start'] = self.config.get('dhcp', 'pool_start', fallback='192.168.1.150')
            dhcp.config['pool_end'] = self.config.get('dhcp', 'pool_end', fallback='192.168.1.200')
            dhcp.config['dns_servers'] = self.config.get('dhcp', 'dns_servers', fallback='192.168.1.10,192.168.1.11').split(',')
            
            dhcp.save_config()
            
            print(f"[SUCCESS] ✓ Database initialized: {db_path}")
            return True
            
        except Exception as e:
            print(f"[ERROR] Database setup failed: {e}")
            return False
    
    def check_ngrok(self):
        """Check if NGROK is installed"""
        print("\n[STEP 5] Checking NGROK...")
        
        try:
            result = subprocess.run(['ngrok', 'version'], capture_output=True, text=True)
            if result.returncode == 0:
                version = result.stdout.strip()
                print(f"[SUCCESS] ✓ NGROK installed: {version}")
                return True
        except:
            pass
        
        print("[WARNING] NGROK not found in PATH")
        print("\n" + "="*70)
        print("NGROK INSTALLATION")
        print("="*70)
        print("1. Download NGROK from: https://ngrok.com/download")
        print("2. Extract ngrok.exe to this directory (or add to PATH)")
        print("3. Sign up for free account at: https://dashboard.ngrok.com/signup")
        print("4. Get auth token from: https://dashboard.ngrok.com/get-started/your-authtoken")
        print("5. Run: ngrok config add-authtoken YOUR_TOKEN")
        print("="*70)
        
        return False
    
    def create_start_scripts(self):
        """Create convenient start scripts"""
        print("\n[STEP 6] Creating start scripts...")
        
        # Start NGROK script
        ngrok_script = f"""@echo off
cd /d "%~dp0"
echo Starting NGROK tunnel...
ngrok tcp {self.config.get('server', 'port', fallback='2222')} --subdomain {self.config.get('server', 'subdomain', fallback='customer')}
"""
        
        with open('start_ngrok.bat', 'w') as f:
            f.write(ngrok_script)
        
        # Start VPN Server script
        server_script = f"""@echo off
cd /d "%~dp0"
echo Starting N2NHU VPN Server...
python v12-nms-server-PRODUCTION.py
pause
"""
        
        with open('start_server.bat', 'w') as f:
            f.write(server_script)
        
        # Combined startup script
        combined_script = """@echo off
cd /d "%~dp0"
echo N2NHU VPN Server - Starting both NGROK and Server
echo.

:: Start NGROK in new window
start "NGROK Tunnel" cmd /k start_ngrok.bat

:: Wait 5 seconds for NGROK to initialize
echo Waiting for NGROK to initialize...
timeout /t 5 /nobreak > nul

:: Start VPN Server
echo Starting VPN Server...
python v12-nms-server-PRODUCTION.py

pause
"""
        
        with open('start_all.bat', 'w') as f:
            f.write(combined_script)
        
        print("[SUCCESS] ✓ Start scripts created:")
        print("  - start_ngrok.bat  (Start NGROK tunnel)")
        print("  - start_server.bat (Start VPN server)")
        print("  - start_all.bat    (Start both)")
        
        return True
    
    def print_summary(self):
        """Print setup summary and next steps"""
        print("\n" + "="*70)
        print("SETUP COMPLETE!")
        print("="*70)
        print()
        print("Next steps:")
        print()
        print("1. Configure NGROK (if not done):")
        print("   ngrok config add-authtoken YOUR_TOKEN")
        print()
        print("2. Start the server:")
        print("   Option A: Run start_all.bat (starts NGROK + Server)")
        print("   Option B: Run start_server.bat (server only)")
        print()
        print("3. Configure Virtual DHCP:")
        print("   The server will guide you through DHCP setup on first run")
        print("   You can configure:")
        print("   - Network bridge interface")
        print("   - DHCP IP pool range")
        print("   - Gateway and DNS servers")
        print()
        print("4. Your server will be accessible at:")
        print(f"   Local: localhost:{self.config.get('server', 'port', fallback='2222')}")
        print(f"   NGROK: {self.config.get('server', 'subdomain', fallback='customer')}.ngrok.io")
        print()
        print("="*70)
        print()
        print("NOTE: The TAP adapter should already be installed by OpenVPN.")
        print("Network bridge configuration will be done through the server menu.")
        print()
    
    def run_setup(self):
        """Run complete setup process"""
        print("\n" + "="*70)
        print("N2NHU VPN SERVER - AUTOMATED SETUP")
        print("="*70)
        print()
        
        # Prerequisites
        if not self.check_windows():
            return False
        
        if not self.check_admin():
            return False
        
        if not self.check_python_version():
            return False
        
        # Installation steps
        if not self.install_dependencies():
            return False
        
        # Check for TAP tools (modern or legacy)
        if not self.check_tap_driver():
            return False
        
        # Check if TAP adapter already exists
        self.check_tap_adapter_exists()
        
        # Database
        self.setup_database()
        
        # NGROK check
        self.check_ngrok()
        
        # Create scripts
        self.create_start_scripts()
        
        # Summary
        self.print_summary()
        
        return True


def main():
    setup = ServerSetup()
    success = setup.run_setup()
    
    if success:
        print("\n[SUCCESS] Setup completed successfully!")
        sys.exit(0)
    else:
        print("\n[ERROR] Setup encountered errors - please review messages above")
        sys.exit(1)


if __name__ == "__main__":
    main()
